@echo off
cd /d "%~dp0"
python vr_app.py --host 0.0.0.0 --port 8765 --import-on-start
if errorlevel 1 (
  py vr_app.py --host 0.0.0.0 --port 8765 --import-on-start
)
pause
