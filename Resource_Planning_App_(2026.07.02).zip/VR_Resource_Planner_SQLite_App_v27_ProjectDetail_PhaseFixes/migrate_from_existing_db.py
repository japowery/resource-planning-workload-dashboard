#!/usr/bin/env python3
"""Copy manual V&R Resource Planner edits from an older SQLite DB into this app's DB.

Usage:
    python migrate_from_existing_db.py --from "C:\\path\\to\\old\\resource_planner.sqlite" --to resource_planner.sqlite

If the old DB used WAL mode, copy the matching .sqlite-wal and .sqlite-shm files into the
same folder as the old .sqlite file before running this script. SQLite needs those files to
see the latest committed edits.
"""
from __future__ import annotations
import argparse
import sqlite3
from pathlib import Path

REGISTRY_FIELDS = [
    "status", "witness", "project_manager", "analyst", "start_date", "filing_date", "hearing_date",
    "hearing_not_required", "project_name_override", "budget_mode", "prefiling_budget_override",
    "post_filing_budget_override", "post_filing_hours_override", "notes",
]
TASK_FIELDS = ["status", "include_flag", "comment"]
NA_VALUES = {"N/A", "NA", "NONE", "NO HEARING", "NOT APPLICABLE"}


def conn(path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(str(path), timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=10000")
    return c


def cols(c: sqlite3.Connection, table: str) -> set[str]:
    try:
        return {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
    except sqlite3.Error:
        return set()


def table_exists(c: sqlite3.Connection, table: str) -> bool:
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def clean_status(v: str) -> str:
    if not v or v == "Unassigned":
        return "Active"
    if v not in {"Active", "Upcoming", "On Hold", "Inactive"}:
        return "Active"
    return v


def target_codes_for_source(dst, code: str) -> list[str]:
    """Return target project codes for a source code from an older DB.

    Older app versions used one parent project code. Newer phase-level versions use
    base.phase codes. Parent-level manual entries are copied to all numeric phase
    rows for the same base. This preserves staff/date/status edits after the
    VantagePoint phase export is adopted.
    """
    raw = str(code or '').strip()
    base = raw.split('.', 1)[0].zfill(6) if raw.split('.', 1)[0].isdigit() else raw.split('.', 1)[0]
    if dst.execute("SELECT 1 FROM project_registry WHERE project_code=?", (raw,)).fetchone():
        return [raw]
    rows = [r[0] for r in dst.execute(
        """
        SELECT project_code FROM projects
        WHERE (base_project_code=? OR project_code LIKE ?)
          AND coalesce(phase_code,'') GLOB '[0-9]*'
        ORDER BY CASE WHEN phase_code='100' THEN 0 ELSE 1 END, phase_code, project_code
        """,
        (base, base + '.%'),
    )]
    return rows


def transform_registry_for_target(row, src_cols, target_code: str, target_phase: str, copy_blanks: bool) -> dict:
    updates = {}
    for field in REGISTRY_FIELDS:
        if field not in src_cols:
            continue
        val = row[field]
        if field == "status":
            val = clean_status(str(val or ""))
        if copy_blanks or str(val or "") != "":
            updates[field] = val
    # Phase-aware conversion for the simplified Start/End/Post-Filing model.
    phase = str(target_phase or '').strip()
    is_post = phase.startswith('2') or phase >= '200'
    old_start = row['start_date'] if 'start_date' in src_cols else ''
    old_filing = row['filing_date'] if 'filing_date' in src_cols else ''
    old_hearing = row['hearing_date'] if 'hearing_date' in src_cols else ''
    if is_post:
        if old_filing:
            updates['start_date'] = old_filing
        if old_hearing:
            # New UI treats filing_date as the row's End Date.
            updates['filing_date'] = old_hearing
            updates['hearing_date'] = old_hearing
        updates['is_post_filing'] = 1
    else:
        if old_start:
            updates['start_date'] = old_start
        if old_filing:
            updates['filing_date'] = old_filing
        updates['is_post_filing'] = 0
    if "hearing_not_required" in src_cols and row["hearing_not_required"]:
        updates["hearing_not_required"] = 1
    elif "hearing_date" in src_cols:
        hd = str(row["hearing_date"] or "").strip().upper()
        if hd in NA_VALUES:
            updates["hearing_not_required"] = 1
    return updates


def migrate_registry(src, dst, copy_blanks: bool) -> int:
    if not table_exists(src, "project_registry") or not table_exists(dst, "project_registry"):
        return 0
    src_cols, dst_cols = cols(src, "project_registry"), cols(dst, "project_registry")
    count = 0
    for row in src.execute("SELECT * FROM project_registry"):
        src_code = str(row["project_code"]).strip()
        targets = target_codes_for_source(dst, src_code)
        for code in targets:
            target = dst.execute("SELECT phase_code FROM projects WHERE project_code=?", (code,)).fetchone()
            target_phase = target[0] if target else ''
            updates = transform_registry_for_target(row, src_cols, code, target_phase, copy_blanks)
            updates = {k:v for k,v in updates.items() if k in dst_cols}
            if not updates:
                continue
            updates["updated_at"] = row["updated_at"] if "updated_at" in src_cols and row["updated_at"] else "migrated"
            updates["updated_by"] = row["updated_by"] if "updated_by" in src_cols and row["updated_by"] else "migration"
            set_clause = ", ".join(f"{k}=?" for k in updates)
            dst.execute(f"UPDATE project_registry SET {set_clause}, revision=revision+1 WHERE project_code=?", tuple(updates.values()) + (code,))
            count += 1
    return count


def migrate_tasks(src, dst) -> int:
    if not table_exists(src, "project_tasks") or not table_exists(dst, "project_tasks"):
        return 0
    src_cols, dst_cols = cols(src, "project_tasks"), cols(dst, "project_tasks")
    count = 0
    for row in src.execute("SELECT * FROM project_tasks"):
        src_code = str(row["project_code"]).strip()
        tid = int(row["task_id"])
        for code in target_codes_for_source(dst, src_code):
            if dst.execute("SELECT 1 FROM project_tasks WHERE project_code=? AND task_id=?", (code, tid)).fetchone() is None:
                continue
            updates = {}
            for field in TASK_FIELDS:
                if field in src_cols and field in dst_cols:
                    updates[field] = row[field]
            if not updates:
                continue
            updates["updated_at"] = row["updated_at"] if "updated_at" in src_cols and row["updated_at"] else "migrated"
            updates["updated_by"] = row["updated_by"] if "updated_by" in src_cols and row["updated_by"] else "migration"
            set_clause = ", ".join(f"{k}=?" for k in updates)
            dst.execute(f"UPDATE project_tasks SET {set_clause}, revision=revision+1 WHERE project_code=? AND task_id=?", tuple(updates.values()) + (code, tid))
            count += 1
    return count

def audit_exists(dst, r) -> bool:
    return dst.execute(
        """
        SELECT 1 FROM audit_log
        WHERE entity_type=? AND entity_key=? AND coalesce(project_code,'')=? AND coalesce(field_name,'')=?
          AND coalesce(old_value,'')=? AND coalesce(new_value,'')=? AND coalesce(updated_by,'')=? AND updated_at=?
        LIMIT 1
        """,
        (r["entity_type"], r["entity_key"], r["project_code"] or "", r["field_name"] or "", r["old_value"] or "", r["new_value"] or "", r["updated_by"] or "", r["updated_at"]),
    ).fetchone() is not None


def migrate_audit(src, dst) -> int:
    if not table_exists(src, "audit_log") or not table_exists(dst, "audit_log"):
        return 0
    count = 0
    for r in src.execute("SELECT entity_type, entity_key, project_code, field_name, old_value, new_value, updated_by, updated_at FROM audit_log ORDER BY id"):
        if audit_exists(dst, r):
            continue
        dst.execute(
            """
            INSERT INTO audit_log(entity_type, entity_key, project_code, field_name, old_value, new_value, updated_by, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (r["entity_type"], r["entity_key"], r["project_code"], r["field_name"], r["old_value"], r["new_value"], r["updated_by"], r["updated_at"]),
        )
        count += 1
    return count


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="src", required=True, help="Old resource_planner.sqlite path")
    ap.add_argument("--to", dest="dst", default="resource_planner.sqlite", help="New target resource_planner.sqlite path")
    ap.add_argument("--copy-blanks", action="store_true", help="Also copy blank registry values from old DB, clearing target defaults")
    args = ap.parse_args()
    src_path, dst_path = Path(args.src), Path(args.dst)
    if not src_path.exists():
        raise SystemExit(f"Source DB not found: {src_path}")
    if not dst_path.exists():
        raise SystemExit(f"Target DB not found: {dst_path}")
    with conn(src_path) as src, conn(dst_path) as dst:
        dst.execute("BEGIN IMMEDIATE")
        reg = migrate_registry(src, dst, args.copy_blanks)
        tasks = migrate_tasks(src, dst)
        audit = migrate_audit(src, dst)
        dst.commit()
    print(f"Migration complete. Registry rows updated: {reg}; task rows updated: {tasks}; audit rows copied: {audit}.")

if __name__ == "__main__":
    main()
