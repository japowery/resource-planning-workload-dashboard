#!/usr/bin/env python3
"""
V&R Resource Planner - SQLite + local web server

Run:
    python vr_app.py --import-on-start
    open http://127.0.0.1:8765

Designed for a central deployment pattern: one server process owns the SQLite file,
multiple users access it through the browser UI/API.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import mimetypes
import os
import posixpath
import re
import sqlite3
import sys
import threading
import time
import traceback
import urllib.parse
import zipfile
from collections import defaultdict
from contextlib import closing
from datetime import date, datetime, timedelta
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import xml.etree.ElementTree as ET

APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "config.json"
DEFAULT_PORT = 8765

NS = {
    "a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}

ROLE_ASSUMPTIONS = [
    {"role": "Witness", "standard_hours": 31.0, "rate": 350.0, "target_utilization": 0.75},
    {"role": "Project Manager", "standard_hours": 55.0, "rate": 250.0, "target_utilization": 0.80},
    {"role": "Analyst", "standard_hours": 93.0, "rate": 210.0, "target_utilization": 0.85},
    {"role": "Admin", "standard_hours": 21.0, "rate": 160.0, "target_utilization": 0.50},
]

BILLING_RATES = [
    {"billing_role": "John J. Spanos, President", "rate": 360.0},
    {"billing_role": "Ned W. Allis, Senior Vice President", "rate": 340.0},
    {"billing_role": "Harold Walker, III, Manager, Financial Studies", "rate": 330.0},
    {"billing_role": "Bryan P. Berry, Vice President, Energy", "rate": 330.0},
    {"billing_role": "John F. Wiedmayer, Jr., Senior Project Manager, Depreciation Studies", "rate": 320.0},
    {"billing_role": "Project Manager, Depreciation Studies", "rate": 260.0},
    {"billing_role": "Project Manager, Rate Studies", "rate": 260.0},
    {"billing_role": "Assistant Project Manager", "rate": 240.0},
    {"billing_role": "Senior Project Analysts", "rate": 235.0},
    {"billing_role": "Project Analysts", "rate": 220.0},
    {"billing_role": "Senior Analysts", "rate": 200.0},
    {"billing_role": "Analysts", "rate": 190.0},
    {"billing_role": "Associate Analysts", "rate": 180.0},
    {"billing_role": "Senior Technicians", "rate": 150.0},
    {"billing_role": "Support Staff", "rate": 160.0},
]

SUPERVISORY_BILLING_ROLE_BY_EMPLOYEE = {
    "John Spanos": "John J. Spanos, President",
    "Ned Allis": "Ned W. Allis, Senior Vice President",
    "Harold Walker": "Harold Walker, III, Manager, Financial Studies",
    "Bryan Berry": "Bryan P. Berry, Vice President, Energy",
    "John Wiedmayer": "John F. Wiedmayer, Jr., Senior Project Manager, Depreciation Studies",
}

def default_billing_role(employee: str, planning_role: str) -> str:
    emp = str(employee or "").strip()
    if emp in SUPERVISORY_BILLING_ROLE_BY_EMPLOYEE:
        return SUPERVISORY_BILLING_ROLE_BY_EMPLOYEE[emp]
    role = str(planning_role or "").strip()
    if role == "Admin":
        return "Support Staff"
    if role == "Analyst":
        return "Project Analysts"
    if role == "Project Manager":
        return "Project Manager, Depreciation Studies"
    if role == "Witness":
        return "Project Manager, Depreciation Studies"
    return "Project Analysts"

def default_staff_hours_week(employee: str, planning_role: str) -> float:
    return 40.0

def default_staff_pto_days(employee: str, planning_role: str) -> float:
    return 20.0
STANDARD_HOURS = sum(r["standard_hours"] for r in ROLE_ASSUMPTIONS)
BLENDED_RATE = sum(r["standard_hours"] * r["rate"] for r in ROLE_ASSUMPTIONS) / STANDARD_HOURS
STATUS_OPTIONS = ["Active", "Upcoming", "On Hold", "Inactive", "Exclude"]
BUDGET_MODE_OPTIONS = ["Auto", "Pre-Filing Only", "Pre+Post Filing", "Manual Split"]
TASK_STAGE_PREFILING = "Pre-Filing"
TASK_STAGE_POSTFILING = "Post-Filing"
DEFAULT_PTO_DAYS = 20.0
DEFAULT_HOLIDAYS_DAYS = 10.0
DEFAULT_NONWORKING_DAYS = DEFAULT_PTO_DAYS + DEFAULT_HOLIDAYS_DAYS
TASK_STATUS_OPTIONS = ["Complete", "Pending Review", "In Progress", "Not Started", "Not Required"]
TASK_STATUS_WEIGHT = {"Complete": 1.0, "Pending Review": 0.9, "In Progress": 0.5, "Not Started": 0.0, "Not Required": 0.0}


def load_config() -> dict:
    if CONFIG_PATH.exists():
        with CONFIG_PATH.open("r", encoding="utf-8") as f:
            cfg = json.load(f)
    else:
        cfg = {}
    return cfg


def resolve_path(raw: str | None) -> Path | None:
    if not raw:
        return None
    p = Path(raw)
    if not p.is_absolute():
        p = APP_DIR / p
    return p


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def today_iso() -> str:
    return date.today().isoformat()


def parse_num(value) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip().replace("$", "").replace(",", "")
    if s in ("", "-"):
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def parse_pct(value) -> float:
    if value is None:
        return 0.0
    s = str(value).strip()
    if s.endswith("%"):
        return parse_num(s[:-1]) / 100.0
    return parse_num(s)


def excel_serial_to_date(value) -> str:
    try:
        d = date(1899, 12, 30) + timedelta(days=float(value))
        return d.isoformat()
    except Exception:
        return ""


def add_days(iso: str, days: int) -> str:
    if not iso:
        return ""
    try:
        d = datetime.strptime(iso, "%Y-%m-%d").date()
        return (d + timedelta(days=days)).isoformat()
    except Exception:
        return ""


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def col_to_num(col: str) -> int:
    n = 0
    for ch in col.upper():
        if "A" <= ch <= "Z":
            n = n * 26 + ord(ch) - 64
    return n


def read_xlsx_rows(path: Path, sheet_index: int = 0):
    """Return [(row_number, {1-based-col: value})]. Uses cached values for formula cells."""
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("a:si", NS):
                shared.append("".join(t.text or "" for t in si.findall(".//a:t", NS)))

        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        relmap = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels}
        sheets = list(wb.find("a:sheets", NS))
        if sheet_index >= len(sheets):
            raise ValueError(f"Workbook {path} does not have sheet index {sheet_index}")
        sheet = sheets[sheet_index]
        rid = sheet.attrib[f"{{{NS['r']}}}id"]
        target = relmap[rid]
        target = f"xl/{target}" if not target.startswith("/") else target.lstrip("/")
        root = ET.fromstring(z.read(target))
        rows = []
        for row in root.findall(".//a:sheetData/a:row", NS):
            row_values = {}
            for c in row.findall("a:c", NS):
                ref = c.attrib.get("r", "")
                m = re.match(r"([A-Z]+)(\d+)", ref)
                if not m:
                    continue
                col = col_to_num(m.group(1))
                t = c.attrib.get("t")
                value = ""
                if t == "s":
                    ve = c.find("a:v", NS)
                    value = shared[int(ve.text)] if ve is not None and ve.text is not None else ""
                elif t == "inlineStr":
                    value = "".join(tt.text or "" for tt in c.findall(".//a:t", NS))
                else:
                    ve = c.find("a:v", NS)
                    value = ve.text if ve is not None and ve.text is not None else ""
                row_values[col] = value
            if row_values:
                rows.append((int(row.attrib.get("r", "0")), row_values))
        return rows


def extract_vp_project_root(text: str) -> str:
    """Return the VantagePoint project root to the left of the period.

    Examples: AG085439.000 -> AG085439; A0000196.000 -> A0000196;
    AGD86348.000 -> AGD86348; ZNPT0004.003 -> ZNPT0004.
    """
    text = str(text or "")
    m = re.search(r"\b([A-Z]{0,5}\d{4,7})(?:\.[A-Za-z0-9]+)", text, flags=re.I)
    if m:
        return m.group(1).upper()
    m = re.search(r"\b([A-Z]{0,5}\d{4,7})\b", text, flags=re.I)
    return m.group(1).upper() if m else ""


def extract_vp_project_id(text: str) -> str:
    """Return the full VantagePoint project identifier, including the suffix.

    This is intentionally more specific than extract_vp_project_root. Some
    VantagePoint project roots have multiple sibling projects, e.g.
    A0000431.000 and A0000431.001. Dropping the suffix collapses distinct
    projects into one planning row.
    """
    text = str(text or "")
    m = re.search(r"\b([A-Z]{0,5}\d{4,7})\.([A-Za-z0-9]+)\b", text, flags=re.I)
    if m:
        return f"{m.group(1).upper()}.{m.group(2).upper()}"
    return extract_vp_project_root(text)


def extract_vp_project_suffix(text: str) -> str:
    text = str(text or "")
    m = re.search(r"\b[A-Z]{0,5}\d{4,7}\.([A-Za-z0-9]+)\b", text, flags=re.I)
    return m.group(1).upper() if m else ""


def extract_project_code_with_vp_suffix(text: str) -> str:
    """Return the app base code while retaining meaningful VP project suffixes.

    The historical app code used only the project root (e.g. A0000431.001 ->
    000431). That lost separate sibling projects. Current rule:
      - .000 keeps the old six-digit/root code for compatibility.
      - non-.000 suffixes append '-suffix' (e.g. A0000431.001 -> 000431-001).
    Phase is still appended separately by compose_phase_project_code.
    """
    base = extract_project_code(text)
    suffix = extract_vp_project_suffix(text)
    if base and suffix and suffix != "000":
        return f"{base}-{suffix}"
    return base


def extract_project_code(text: str) -> str:
    """Return the app's canonical project root.

    For normal GF project numbers with a letter prefix plus six/seven digits, keep
    the numeric root for compatibility with existing registry edits. For alphanumeric
    legacy/special numbers that do not end with six digits, retain the VP root.
    """
    root = extract_vp_project_root(text)
    if not root:
        return ""
    m = re.fullmatch(r"[A-Z]{0,3}(\d{6,7})", root, flags=re.I)
    if m:
        return m.group(1)[-6:]
    return root


def normalize_phase_code(raw) -> str:
    s = str(raw or "").strip().upper()
    s = re.sub(r"[^A-Z0-9]+", "", s)
    return s or "000"


def compose_phase_project_code(base_code: str, phase_code: str = "") -> str:
    raw = str(base_code or "").strip().upper()
    if re.fullmatch(r"\d{1,6}(?:-[A-Z0-9]+)?", raw, flags=re.I):
        base_part, dash, suffix = raw.partition("-")
        base = base_part.zfill(6) + ((dash + suffix) if dash else "")
    else:
        base = extract_project_code_with_vp_suffix(raw) or extract_project_code(raw) or raw
        base = base.zfill(6) if re.fullmatch(r"\d{1,6}", base) else base
    phase = normalize_phase_code(phase_code)
    return f"{base}.{phase}" if phase else base


def project_base_code(code: str) -> str:
    s = str(code or "").strip()
    # Project codes may now contain a VP suffix in the base portion, e.g.
    # 000431-001.100. Split from the right so the phase is removed but the
    # VP suffix remains part of the base project key.
    if "." in s:
        return s.rsplit(".", 1)[0]
    return extract_project_code_with_vp_suffix(s) or extract_project_code(s) or (s.zfill(6) if re.fullmatch(r"\d{1,6}", s) else s)


def is_revenue_or_excluded_phase(phase_code: str, phase_name: str = "") -> bool:
    text = f"{phase_code} {phase_name}".upper()
    return phase_code.upper().startswith("ZZ") or "REVENUE TRUE" in text or "BUSINESS DEVELOPMENT" in text or "BD" == phase_code.upper()


def financial_phase_stage(phase_code: str, phase_name: str = "") -> str:
    text = f"{phase_code} {phase_name}".upper()
    if is_revenue_or_excluded_phase(phase_code, phase_name):
        return "Exclude"
    if phase_code.upper().startswith("2") or "POST" in text or "REBUTTAL" in text or "HEARING" in text or "DISCOVERY" in text:
        return TASK_STAGE_POSTFILING
    return TASK_STAGE_PREFILING


def normalize_project_code(raw) -> str:
    s = str(raw or "").strip()
    if not s:
        return ""
    # Already-normalized app codes, including sibling VP project suffixes.
    if re.fullmatch(r"[A-Z0-9]+(?:-[A-Z0-9]+)?(?:\.[A-Z0-9]+)?", s, flags=re.I):
        if "-" in s or re.fullmatch(r"\d{1,6}(?:\.[A-Z0-9]+)?", s, flags=re.I):
            left, dot, right = s.partition(".")
            if re.fullmatch(r"\d{1,6}(?:-[A-Z0-9]+)?", left, flags=re.I):
                left = left.zfill(6) if "-" not in left else left
                return f"{left}.{right}" if dot else left
    full_vp = extract_vp_project_id(s)
    if full_vp:
        return extract_project_code_with_vp_suffix(full_vp)
    root = extract_project_code(s)
    return root.zfill(6) if re.fullmatch(r"\d{1,6}", root) else (root or (s.zfill(6) if re.fullmatch(r"\d{1,6}", s) else s))


def description_from_project_line(text: str) -> str:
    """Return only the human-readable project description, not the VantagePoint label/code."""
    s = str(text or "").strip()
    s = re.sub(r"^Project\s+Number:\s*", "", s, flags=re.I).strip()
    s = re.sub(r"^[A-Z]{0,5}\d{4,7}(?:\.[A-Za-z0-9]+)?\s*[-–—:]?\s*", "", s).strip()
    return s or str(text or "").strip()


def infer_status(budget: float, effort: float, phase_code: str = "", phase_name: str = "") -> str:
    if is_revenue_or_excluded_phase(phase_code, phase_name):
        return "Exclude"
    # Do not infer Inactive simply because effort exceeds budget. Over-budget
    # work can still be active, and auto-hiding it caused legitimate projects
    # to disappear from the default Portfolio view. Inactive should be a user
    # decision.
    if budget <= 0 and effort <= 0:
        return "Upcoming"
    return "Active"


def infer_task_stage(phase: str, task: str = "") -> str:
    text = f"{phase} {task}".upper()
    if "PHASE 10" in text or "POST-FILING" in text or "POST FILING" in text or any(k in text for k in ["DISCOVERY", "REBUTTAL", "HEARING"]):
        return TASK_STAGE_POSTFILING
    return TASK_STAGE_PREFILING


def split_budget(total_budget: float, budget_mode: str, pre_override: float, post_override: float) -> tuple[float, float, str]:
    """Current planning rule: VantagePoint budget is treated as pre-filing only.

    Post-filing work is forecast separately for resource planning when a hearing
    exists. This intentionally ignores legacy/manual budget split fields so hidden
    overrides cannot affect current dashboards. The columns remain in the database
    only for backward compatibility and future versions.
    """
    total = max(0.0, parse_num(total_budget))
    return total, 0.0, "VantagePoint budget treated as pre-filing only; post-filing hours are forecast separately when a hearing exists"




def hearing_is_na(value, flag=0) -> bool:
    s = str(value or "").strip().upper()
    return bool(flag) or s in {"N/A", "NA", "NONE", "NO HEARING", "NOT APPLICABLE"}


def post_filing_forecast_hours(prefiling_budgeted_hours: float, hearing_date: str, hearing_not_required: int = 0, manual_override: float = 0) -> float:
    """Expected post-filing hours for workload planning, independent of budget.

    Current planning rule: if Hearing is N/A or blank, post-filing forecast is zero.
    If a hearing date exists, forecast post-filing effort at 50% of pre-filing hours.
    The manual override argument is ignored for now; it remains only for backward
    compatibility and possible future versions.
    """
    if hearing_is_na(hearing_date, hearing_not_required) or not str(hearing_date or "").strip():
        return 0.0
    return max(0.0, parse_num(prefiling_budgeted_hours) * 0.50)


def remaining_hours_from_budget(budget: float, effort_to_date: float, blended_rate: float = BLENDED_RATE) -> float:
    br = parse_num(blended_rate) or BLENDED_RATE
    return max(0.0, (parse_num(budget) - parse_num(effort_to_date)) / br) if parse_num(budget) > 0 else 0.0



def default_role_assumption_rows() -> list[dict]:
    total = sum(r["standard_hours"] for r in ROLE_ASSUMPTIONS) or 1.0
    return [
        {
            "role": r["role"],
            "standard_hours": r["standard_hours"],
            "rate": r["rate"],
            "target_utilization": r["target_utilization"],
            "hour_share": r["standard_hours"] / total,
        }
        for r in ROLE_ASSUMPTIONS
    ]


def role_metrics_from_db(conn: sqlite3.Connection) -> tuple[list[dict], float, float]:
    rows = [dict(r) for r in conn.execute("SELECT * FROM role_assumptions ORDER BY CASE role WHEN 'Witness' THEN 1 WHEN 'Project Manager' THEN 2 WHEN 'Analyst' THEN 3 WHEN 'Admin' THEN 4 ELSE 5 END")]
    if not rows:
        rows = default_role_assumption_rows()
    total_hours = sum(parse_num(r.get("standard_hours")) for r in rows) or STANDARD_HOURS
    blended_rate = sum(parse_num(r.get("standard_hours")) * parse_num(r.get("rate")) for r in rows) / total_hours if total_hours else BLENDED_RATE
    for r in rows:
        r["hour_share"] = parse_num(r.get("standard_hours")) / total_hours if total_hours else 0.0
    return rows, total_hours, blended_rate


def reset_role_assumptions_table(conn: sqlite3.Connection):
    conn.execute("DELETE FROM role_assumptions")
    for r in default_role_assumption_rows():
        conn.execute(
            "INSERT INTO role_assumptions(role, standard_hours, rate, target_utilization, hour_share) VALUES (?, ?, ?, ?, ?)",
            (r["role"], r["standard_hours"], r["rate"], r["target_utilization"], r["hour_share"]),
        )


def default_effort_distribution_rows(cfg: dict) -> list[dict]:
    dist_path = resolve_path(cfg.get("effort_distribution_csv_path"))
    rows: list[dict] = []
    if dist_path and dist_path.exists():
        for i, r in enumerate(read_csv_rows(dist_path), start=1):
            day_raw = str(r.get("Day #") or r.get("Day") or "").strip()
            m = re.search(r"\d+", day_raw)
            day = int(m.group(0)) if m else i
            rows.append({
                "seq": i,
                "timeline_pct": parse_pct(r.get("Timeline")),
                "day_number": day,
                "witness_pct": parse_pct(r.get("Witness % Complete")),
                "project_manager_pct": parse_pct(r.get("Project Manager % Complete")),
                "analyst_pct": parse_pct(r.get("Analyst % Complete")),
                "admin_pct": parse_pct(r.get("Admin % Complete")),
                "combined_pct": parse_pct(r.get("Combined % Complete")),
                "comments": r.get("Comments", ""),
            })
    if rows:
        return rows
    # Embedded fallback matching the current V&R default curve.
    fallback = [
        (0.05,15,0.05,0.07,0.07,0.10,0.06,"Project Start"),(0.10,30,0.06,0.10,0.10,0.04,0.08,""),(0.15,45,0.05,0.11,0.11,0.04,0.08,""),(0.20,60,0.07,0.11,0.11,0.05,0.09,""),(0.25,75,0.09,0.07,0.07,0.04,0.08,"Typical Site Visit Timing"),(0.30,90,0.05,0.07,0.07,0.06,0.06,""),(0.35,105,0.05,0.06,0.06,0.06,0.06,""),(0.40,120,0.04,0.05,0.05,0.07,0.05,""),(0.45,135,0.04,0.05,0.05,0.05,0.05,""),(0.50,150,0.03,0.04,0.04,0.05,0.04,""),(0.55,165,0.06,0.04,0.04,0.05,0.05,""),(0.60,180,0.06,0.04,0.04,0.05,0.05,""),(0.65,195,0.07,0.04,0.04,0.05,0.05,""),(0.70,210,0.08,0.03,0.03,0.05,0.06,"Typical Filing Date Timing"),(0.75,225,0.04,0.03,0.03,0.05,0.03,""),(0.80,240,0.06,0.02,0.02,0.05,0.04,"Typical Rebuttal (if applicable) Timing"),(0.85,255,0.04,0.02,0.02,0.04,0.03,""),(0.90,270,0.03,0.02,0.02,0.04,0.02,"Typical Hearing (if applicable) Timing"),(0.95,285,0.02,0.02,0.02,0.04,0.02,""),(1.00,300,0.01,0.01,0.01,0.02,0.01,""),
    ]
    return [dict(seq=i, timeline_pct=a, day_number=b, witness_pct=c, project_manager_pct=d, analyst_pct=e, admin_pct=f, combined_pct=g, comments=h) for i,(a,b,c,d,e,f,g,h) in enumerate(fallback, start=1)]


def reset_effort_distribution_table(conn: sqlite3.Connection, cfg: dict):
    conn.execute("DELETE FROM effort_distribution")
    for r in default_effort_distribution_rows(cfg):
        conn.execute(
            """
            INSERT INTO effort_distribution(seq, timeline_pct, day_number, witness_pct, project_manager_pct, analyst_pct, admin_pct, combined_pct, comments)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (r["seq"], r["timeline_pct"], r["day_number"], r["witness_pct"], r["project_manager_pct"], r["analyst_pct"], r["admin_pct"], r["combined_pct"], r.get("comments", "")),
        )

def normalize_name(name: str) -> str:
    s = str(name or "").strip()
    if "," in s:
        last, first = [x.strip() for x in s.split(",", 1)]
        s = f"{first} {last}"
    s = re.sub(r"[^A-Za-z ]+", " ", s).lower()
    parts = [p for p in s.split() if p]
    parts = [p for p in parts if len(p) > 1]
    return " ".join(parts)


def read_csv_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def read_xlsx_rows_all_sheets(path: Path):
    rows = []
    for idx in range(20):
        try:
            rows.extend((idx, rn, row) for rn, row in read_xlsx_rows(path, idx))
        except Exception:
            break
    return rows


def parse_financials(path: Path) -> tuple[list[dict], list[dict]]:
    """Parse VantagePoint project summary.

    Current preferred format:
      - project/phase report, with phase total rows
      - project number in column B, phase in column D
      - budget in column G, effort to date in column H

    Backward compatibility:
      - older export with helper columns W/X and budget K / effort U.
    """
    raw_lines: list[dict] = []
    aggregated: dict[str, dict] = {}
    current_vp_project = ""
    current_root_code = ""
    current_project_desc = ""
    current_phase_code = ""
    current_phase_name = ""

    for _sheet_idx, rn, row in read_xlsx_rows_all_sheets(path):
        col_a = str(row.get(1, "")).strip()
        if col_a.startswith("Project Number:"):
            current_vp_project = str(row.get(2, "")).strip() or extract_vp_project_id(col_a)
            current_root_code = extract_project_code_with_vp_suffix(current_vp_project or col_a)
            current_project_desc = description_from_project_line(col_a)
            current_phase_code = ""
            current_phase_name = ""
            continue
        if col_a.startswith("Phase Number:"):
            phase_text = col_a.split(":", 1)[1].strip()
            parts = phase_text.split(None, 1)
            current_phase_code = normalize_phase_code(parts[0] if parts else "")
            current_phase_name = parts[1].strip() if len(parts) > 1 else phase_text
            continue
        if not col_a.startswith("Total for "):
            continue
        # Exclude project-level total rows such as "Total for A0000196.000",
        # "Total for AG085439.000", or "Total for PG085439.000"; keep phase totals only.
        total_label = col_a.replace("Total for", "", 1).strip()
        if re.fullmatch(r"[A-Z]{0,5}\d{4,7}\.[A-Z0-9]+", total_label, flags=re.I):
            continue
        vp_project = str(row.get(2, "")).strip() or current_vp_project
        root_code = extract_project_code_with_vp_suffix(vp_project) or current_root_code
        phase_code = normalize_phase_code(row.get(4, "") or current_phase_code or total_label)
        # Planning rows should only be created for numeric VantagePoint phases.
        # Non-numeric phases such as BDM, ZZREV, ZZZZZ, etc. are excluded at import
        # instead of being carried as inactive/excluded dashboard rows.
        if not root_code or not phase_code or not re.fullmatch(r"\d+", phase_code):
            continue
        budget = parse_num(row.get(7))
        effort = parse_num(row.get(8))
        # Skip completely blank phase totals only if they are not meaningful revenue/exclude rows.
        phase_name = current_phase_name or phase_code
        project_desc = current_project_desc or description_from_project_line(str(vp_project)) or root_code
        desc = f"{project_desc} - {phase_code} {phase_name}".strip()
        code = compose_phase_project_code(root_code, phase_code)
        vp_root = extract_vp_project_root(vp_project)
        line = {
            "project_code": code,
            "base_project_code": root_code,
            "phase_code": phase_code,
            "phase_name": phase_name,
            "vp_project": vp_project,
            "vp_project_root": vp_root,
            "description": desc,
            "project_name": desc,
            "parent_name": project_desc,
            "budget": budget,
            "effort_to_date": effort,
            "source_row": rn,
        }
        raw_lines.append(line)
        rec = aggregated.setdefault(code, {
            "project_code": code,
            "base_project_code": root_code,
            "phase_code": phase_code,
            "phase_name": phase_name,
            "vp_project": vp_project,
            "project_name": desc,
            "parent_name": project_desc,
            "budget": 0.0,
            "effort_to_date": 0.0,
            "vp_projects": [],
            "financial_source_rows": [],
        })
        rec["budget"] += budget
        rec["effort_to_date"] += effort
        if vp_project and vp_project not in rec["vp_projects"]:
            rec["vp_projects"].append(vp_project)
        rec["financial_source_rows"].append(rn)

    # Backward compatibility for the older helper-column export.
    if not raw_lines:
        for rn, row in read_xlsx_rows(path):
            col_a = str(row.get(1, "")).strip()
            if not col_a.startswith("Project Number:"):
                continue
            vp_project = str(row.get(3, "")).strip()
            code = str(row.get(23, "")).strip() or extract_project_code(vp_project or col_a)
            if not code:
                continue
            desc = str(row.get(24, "")).strip() or description_from_project_line(col_a)
            budget = parse_num(row.get(11))
            effort = parse_num(row.get(21))
            line = {"project_code": code, "base_project_code": project_base_code(code), "phase_code": "", "phase_name": "", "vp_project": vp_project, "description": desc, "budget": budget, "effort_to_date": effort, "source_row": rn}
            raw_lines.append(line)
            rec = aggregated.setdefault(code, {"project_code": code, "base_project_code": project_base_code(code), "phase_code": "", "phase_name": "", "vp_project": vp_project, "project_name": desc, "parent_name": "", "budget": 0.0, "effort_to_date": 0.0, "vp_projects": [], "financial_source_rows": []})
            rec["budget"] += budget
            rec["effort_to_date"] += effort
            rec["vp_projects"].append(vp_project)
            rec["financial_source_rows"].append(rn)
    return list(aggregated.values()), raw_lines


def parse_labor_detail(path: Path, staff_rows: list[dict]) -> tuple[list[dict], dict[str, dict]]:
    staff_alias = {normalize_name(r.get("Employee")): r for r in staff_rows}
    current_code = ""
    rows = []
    for rn, row in read_xlsx_rows(path):
        col_a = str(row.get(1, "")).strip()
        if col_a.startswith("Project Number:"):
            current_code = extract_project_code_with_vp_suffix(col_a)
            continue
        if not current_code:
            continue
        emp_no = str(row.get(4, "")).strip()
        emp_name_raw = str(row.get(5, "")).strip()
        date_raw = row.get(7, "")
        total_hours = parse_num(row.get(10))
        total_billing = parse_num(row.get(14))
        if not emp_no or not emp_name_raw or not date_raw or total_hours == 0:
            continue
        staff = staff_alias.get(normalize_name(emp_name_raw), {})
        rows.append({
            "project_code": current_code,
            "employee_id": emp_no,
            "employee_raw": emp_name_raw,
            "employee": staff.get("Employee", ""),
            "role": staff.get("Role", ""),
            "team": staff.get("Team", ""),
            "labor_date": excel_serial_to_date(date_raw),
            "hours": total_hours,
            "billing": total_billing,
            "source_row": rn,
        })
    defaults: dict[str, dict] = {}
    by_project_employee = defaultdict(lambda: defaultdict(float))
    by_project_role_employee = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
    by_project_dates = defaultdict(list)
    for r in rows:
        code = r["project_code"]
        if r["employee"]:
            by_project_employee[code][r["employee"]] += r["hours"]
        if r["role"] and r["employee"]:
            by_project_role_employee[code][r["role"]][r["employee"]] += r["hours"]
        if r["labor_date"]:
            by_project_dates[code].append(r["labor_date"])
    for code in set(list(by_project_employee.keys()) + list(by_project_dates.keys())):
        start = min(by_project_dates[code]) if by_project_dates[code] else ""
        rec = {
            "project_code": code,
            "default_start_date": start,
            "default_filing_date": add_days(start, 210) if start else "",
            "default_hearing_date": add_days(start, 270) if start else "",
            "default_witness": "",
            "default_project_manager": "",
            "default_analyst": "",
        }
        for role, field in [("Witness", "default_witness"), ("Project Manager", "default_project_manager"), ("Analyst", "default_analyst")]:
            emp_hours = by_project_role_employee[code].get(role, {})
            if emp_hours:
                rec[field] = sorted(emp_hours.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
        defaults[code] = rec
    return rows, defaults


def connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")
    return conn


def init_db(conn: sqlite3.Connection):
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS source_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_kind TEXT NOT NULL,
            path TEXT NOT NULL,
            file_hash TEXT,
            imported_at TEXT NOT NULL,
            row_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'ok',
            message TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS staff (
            employee TEXT PRIMARY KEY,
            role TEXT NOT NULL,
            team TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS role_assumptions (
            role TEXT PRIMARY KEY,
            standard_hours REAL NOT NULL,
            rate REAL NOT NULL,
            target_utilization REAL NOT NULL,
            hour_share REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS billing_rates (
            billing_role TEXT PRIMARY KEY,
            rate REAL NOT NULL,
            updated_at TEXT DEFAULT '',
            updated_by TEXT DEFAULT 'system'
        );

        CREATE TABLE IF NOT EXISTS effort_distribution (
            seq INTEGER PRIMARY KEY,
            timeline_pct REAL NOT NULL,
            day_number INTEGER NOT NULL,
            witness_pct REAL NOT NULL,
            project_manager_pct REAL NOT NULL,
            analyst_pct REAL NOT NULL,
            admin_pct REAL NOT NULL,
            combined_pct REAL NOT NULL,
            comments TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS task_templates (
            task_id INTEGER PRIMARY KEY,
            phase TEXT NOT NULL,
            task TEXT NOT NULL,
            base_hours REAL NOT NULL,
            stage TEXT NOT NULL DEFAULT 'Pre-Filing'
        );

        CREATE TABLE IF NOT EXISTS projects (
            project_code TEXT PRIMARY KEY,
            project_name TEXT NOT NULL,
            parent_name TEXT DEFAULT '',
            budget REAL DEFAULT 0,
            effort_to_date REAL DEFAULT 0,
            vp_projects_json TEXT DEFAULT '[]',
            financial_source_rows_json TEXT DEFAULT '[]',
            updated_from_financials_at TEXT,
            financial_import_hash TEXT,
            project_type TEXT DEFAULT 'vantagepoint',
            base_project_code TEXT DEFAULT '',
            phase_code TEXT DEFAULT '',
            phase_name TEXT DEFAULT '',
            vp_project TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS financial_lines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            import_hash TEXT,
            project_code TEXT,
            base_project_code TEXT DEFAULT '',
            phase_code TEXT DEFAULT '',
            phase_name TEXT DEFAULT '',
            vp_project TEXT,
            description TEXT,
            budget REAL,
            effort_to_date REAL,
            source_row INTEGER,
            imported_at TEXT
        );

        CREATE TABLE IF NOT EXISTS labor_lines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            import_hash TEXT,
            project_code TEXT,
            employee_id TEXT,
            employee_raw TEXT,
            employee TEXT,
            role TEXT,
            team TEXT,
            labor_date TEXT,
            hours REAL,
            billing REAL,
            source_row INTEGER,
            imported_at TEXT
        );

        CREATE TABLE IF NOT EXISTS labor_defaults (
            project_code TEXT PRIMARY KEY,
            default_witness TEXT DEFAULT '',
            default_project_manager TEXT DEFAULT '',
            default_analyst TEXT DEFAULT '',
            default_start_date TEXT DEFAULT '',
            default_filing_date TEXT DEFAULT '',
            default_hearing_date TEXT DEFAULT '',
            computed_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS project_registry (
            project_code TEXT PRIMARY KEY,
            status TEXT DEFAULT 'Unassigned',
            witness TEXT DEFAULT '',
            project_manager TEXT DEFAULT '',
            analyst TEXT DEFAULT '',
            start_date TEXT DEFAULT '',
            filing_date TEXT DEFAULT '',
            hearing_date TEXT DEFAULT '',
            hearing_not_required INTEGER DEFAULT 0,
            is_post_filing INTEGER DEFAULT NULL,
            project_name_override TEXT DEFAULT '',
            budget_mode TEXT DEFAULT 'Auto',
            prefiling_budget_override REAL DEFAULT 0,
            post_filing_budget_override REAL DEFAULT 0,
            post_filing_hours_override REAL DEFAULT 0,
            budget_override REAL DEFAULT NULL,
            effort_override REAL DEFAULT NULL,
            override_reason TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            revision INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            updated_by TEXT DEFAULT 'system',
            FOREIGN KEY(project_code) REFERENCES projects(project_code) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS project_tasks (
            project_code TEXT NOT NULL,
            task_id INTEGER NOT NULL,
            status TEXT DEFAULT 'Not Started',
            include_flag INTEGER DEFAULT 1,
            comment TEXT DEFAULT '',
            revision INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            updated_by TEXT DEFAULT 'system',
            PRIMARY KEY(project_code, task_id),
            FOREIGN KEY(project_code) REFERENCES projects(project_code) ON DELETE CASCADE,
            FOREIGN KEY(task_id) REFERENCES task_templates(task_id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS planning_units (
            unit_id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_project_code TEXT NOT NULL,
            unit_name TEXT NOT NULL,
            allocation_pct REAL DEFAULT 100,
            status TEXT DEFAULT 'Active',
            start_date TEXT DEFAULT '',
            filing_date TEXT DEFAULT '',
            hearing_date TEXT DEFAULT '',
            hearing_not_required INTEGER DEFAULT 0,
            revision INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            updated_by TEXT DEFAULT 'system',
            FOREIGN KEY(parent_project_code) REFERENCES projects(project_code) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS planning_unit_assignments (
            unit_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            employee TEXT NOT NULL,
            allocation_pct REAL DEFAULT 100,
            PRIMARY KEY(unit_id, role, employee),
            FOREIGN KEY(unit_id) REFERENCES planning_units(unit_id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entity_type TEXT NOT NULL,
            entity_key TEXT NOT NULL,
            project_code TEXT,
            field_name TEXT,
            old_value TEXT,
            new_value TEXT,
            updated_by TEXT DEFAULT 'unknown',
            updated_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_audit_project ON audit_log(project_code, updated_at DESC);
        CREATE INDEX IF NOT EXISTS idx_labor_project ON labor_lines(project_code);
        CREATE INDEX IF NOT EXISTS idx_labor_employee ON labor_lines(employee);
        CREATE INDEX IF NOT EXISTS idx_planning_parent ON planning_units(parent_project_code);
        """
    )
    migrate_db(conn)


def ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str):
    cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def migrate_db(conn: sqlite3.Connection):
    ensure_column(conn, "staff", "billing_role", "TEXT DEFAULT ''")
    ensure_column(conn, "staff", "hours_per_week", "REAL DEFAULT 40")
    ensure_column(conn, "staff", "pto_days", "REAL DEFAULT 20")
    ensure_column(conn, "staff", "target_utilization", "REAL DEFAULT NULL")
    ensure_column(conn, "staff", "active", "INTEGER DEFAULT 1")
    ensure_column(conn, "task_templates", "stage", "TEXT NOT NULL DEFAULT 'Pre-Filing'")
    ensure_column(conn, "project_registry", "budget_mode", "TEXT DEFAULT 'Auto'")
    ensure_column(conn, "project_registry", "prefiling_budget_override", "REAL DEFAULT 0")
    ensure_column(conn, "project_registry", "post_filing_budget_override", "REAL DEFAULT 0")
    ensure_column(conn, "project_registry", "post_filing_hours_override", "REAL DEFAULT 0")
    ensure_column(conn, "project_registry", "hearing_not_required", "INTEGER DEFAULT 0")
    ensure_column(conn, "project_registry", "is_post_filing", "INTEGER DEFAULT NULL")
    ensure_column(conn, "project_registry", "project_name_override", "TEXT DEFAULT ''")
    ensure_column(conn, "project_registry", "budget_override", "REAL DEFAULT NULL")
    ensure_column(conn, "project_registry", "effort_override", "REAL DEFAULT NULL")
    ensure_column(conn, "project_registry", "override_reason", "TEXT DEFAULT ''")
    ensure_column(conn, "project_tasks", "base_hours_override", "REAL DEFAULT NULL")
    ensure_column(conn, "projects", "base_project_code", "TEXT DEFAULT ''")
    ensure_column(conn, "projects", "phase_code", "TEXT DEFAULT ''")
    ensure_column(conn, "projects", "phase_name", "TEXT DEFAULT ''")
    ensure_column(conn, "projects", "vp_project", "TEXT DEFAULT ''")
    ensure_column(conn, "financial_lines", "base_project_code", "TEXT DEFAULT ''")
    ensure_column(conn, "financial_lines", "phase_code", "TEXT DEFAULT ''")
    ensure_column(conn, "financial_lines", "phase_name", "TEXT DEFAULT ''")
    ensure_column(conn, "projects", "project_type", "TEXT DEFAULT 'vantagepoint'")
    conn.execute("UPDATE project_registry SET status='Active' WHERE status IS NULL OR status='' OR status='Unassigned'")
    conn.execute("UPDATE project_registry SET hearing_not_required=1 WHERE upper(coalesce(hearing_date,'')) IN ('N/A','NA','NONE','NO HEARING','NOT APPLICABLE')")
    conn.execute("UPDATE task_templates SET stage='Post-Filing' WHERE upper(phase) LIKE '%PHASE 10%' OR upper(phase) LIKE '%POST-FILING%' OR upper(task) IN ('DISCOVERY REQUESTS','REBUTTAL TESTIMONY','HEARING')")
    conn.execute("UPDATE task_templates SET stage='Pre-Filing' WHERE stage IS NULL OR stage='' OR (stage NOT IN ('Pre-Filing','Post-Filing'))")


def reset_billing_rates_table(conn: sqlite3.Connection):
    conn.execute("DELETE FROM billing_rates")
    t = now_iso()
    for r in BILLING_RATES:
        conn.execute("INSERT INTO billing_rates(billing_role, rate, updated_at, updated_by) VALUES (?, ?, ?, 'system')", (r["billing_role"], r["rate"], t))


def seed_static_tables(conn: sqlite3.Connection, cfg: dict):
    t = now_iso()
    # Role assumptions are user-editable. Seed defaults only if the table is empty;
    # reset buttons in the UI intentionally restore defaults.
    if conn.execute("SELECT COUNT(*) AS c FROM role_assumptions").fetchone()["c"] == 0:
        reset_role_assumptions_table(conn)

    if conn.execute("SELECT COUNT(*) AS c FROM billing_rates").fetchone()["c"] == 0:
        reset_billing_rates_table(conn)

    staff_path = resolve_path(cfg.get("staff_csv_path"))
    if staff_path and staff_path.exists():
        for r in read_csv_rows(staff_path):
            employee = (r.get("Employee") or "").strip()
            role = (r.get("Role") or "").strip()
            team = (r.get("Team") or "").strip()
            if employee and role:
                billing_role = default_billing_role(employee, role)
                hours_per_week = default_staff_hours_week(employee, role)
                pto_days = default_staff_pto_days(employee, role)
                default_util = next((x["target_utilization"] for x in ROLE_ASSUMPTIONS if x["role"] == role), 0.8)
                conn.execute(
                    """
                    INSERT INTO staff(employee, role, team, billing_role, hours_per_week, pto_days, target_utilization, active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                    ON CONFLICT(employee) DO UPDATE SET
                        role=excluded.role,
                        team=excluded.team,
                        billing_role=CASE WHEN coalesce(staff.billing_role,'')='' THEN excluded.billing_role ELSE staff.billing_role END,
                        hours_per_week=CASE WHEN coalesce(staff.hours_per_week,0)=0 THEN excluded.hours_per_week ELSE staff.hours_per_week END,
                        pto_days=CASE WHEN staff.pto_days IS NULL THEN excluded.pto_days ELSE staff.pto_days END,
                        target_utilization=CASE WHEN staff.target_utilization IS NULL THEN excluded.target_utilization ELSE staff.target_utilization END,
                        active=COALESCE(staff.active,1)
                    """,
                    (employee, role, team, billing_role, hours_per_week, pto_days, default_util),
                )

    # Fill missing staff defaults for existing databases.
    for row in conn.execute("SELECT employee, role, billing_role, hours_per_week, pto_days, target_utilization FROM staff"):
        updates = {}
        if not row["billing_role"]:
            updates["billing_role"] = default_billing_role(row["employee"], row["role"])
        if not row["hours_per_week"]:
            updates["hours_per_week"] = default_staff_hours_week(row["employee"], row["role"])
        if row["pto_days"] is None:
            updates["pto_days"] = default_staff_pto_days(row["employee"], row["role"])
        if row["target_utilization"] is None:
            updates["target_utilization"] = next((x["target_utilization"] for x in ROLE_ASSUMPTIONS if x["role"] == row["role"]), 0.8)
        if updates:
            sets = ", ".join(f"{k}=?" for k in updates)
            conn.execute(f"UPDATE staff SET {sets} WHERE employee=?", tuple(updates.values()) + (row["employee"],))

    # Effort distribution is user-editable. Seed defaults only if empty.
    if conn.execute("SELECT COUNT(*) AS c FROM effort_distribution").fetchone()["c"] == 0:
        reset_effort_distribution_table(conn, cfg)

    task_path = resolve_path(cfg.get("task_library_csv_path"))
    if task_path and task_path.exists():
        # Do not DELETE/REPLACE task_templates because project_tasks has a foreign key
        # to task_templates. Upsert instead so user-entered task statuses survive imports.
        seen_ids = []
        for i, r in enumerate(read_csv_rows(task_path), start=1):
            phase = r.get("PHASE") or r.get("Phase") or ""
            task = r.get("TASKS") or r.get("Task") or ""
            base = parse_num(r.get("ESTIMATED TOTAL TEAM HOURS") or r.get("BaseTaskHours"))
            stage = r.get("Stage") or r.get("STAGE") or infer_task_stage(phase, task)
            if task:
                seen_ids.append(i)
                conn.execute(
                    """
                    INSERT INTO task_templates(task_id, phase, task, base_hours, stage) VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(task_id) DO UPDATE SET
                        phase=excluded.phase, task=excluded.task, base_hours=excluded.base_hours, stage=excluded.stage
                    """,
                    (i, phase, task, base, stage),
                )
        conn.execute("UPDATE task_templates SET stage='Post-Filing' WHERE upper(phase) LIKE '%PHASE 10%' OR upper(phase) LIKE '%POST-FILING%' OR upper(task) IN ('DISCOVERY REQUESTS','REBUTTAL TESTIMONY','HEARING')")


def conn_staff_rows(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT role AS Role, employee AS Employee, team AS Team FROM staff")]


def seed_project_tasks(conn: sqlite3.Connection, code: str):
    t = now_iso()
    for task in conn.execute("SELECT task_id FROM task_templates"):
        conn.execute(
            """
            INSERT OR IGNORE INTO project_tasks(project_code, task_id, status, include_flag, comment, revision, created_at, updated_at, updated_by)
            VALUES (?, ?, 'Not Started', 1, '', 1, ?, ?, 'system')
            """,
            (code, task["task_id"], t, t),
        )


def legacy_unsuffixed_project_code(code: str) -> str:
    """Return the pre-suffix app code for a split VP sibling row.

    Example: 000431-001.100 -> 000431.100. Used only to carry forward
    existing registry/task edits after disaggregating sibling VP projects.
    """
    s = str(code or "").strip()
    if "-" not in s:
        return ""
    base, dot, phase = s.rpartition(".")
    if not dot:
        base = s
        phase = ""
    m = re.fullmatch(r"(.+)-[A-Z0-9]+", base, flags=re.I)
    if not m:
        return ""
    return f"{m.group(1)}.{phase}" if phase else m.group(1)


def copy_legacy_registry_and_tasks_for_split(conn: sqlite3.Connection, new_code: str, started: str):
    """Copy user-entered planning metadata from the old collapsed key to a new split key.

    This prevents data loss when a VP export has A0000431.000 and A0000431.001
    and the newer importer creates 000431.100 plus 000431-001.100.
    """
    old_code = legacy_unsuffixed_project_code(new_code)
    if not old_code:
        return
    if conn.execute("SELECT 1 FROM project_registry WHERE project_code=?", (new_code,)).fetchone():
        return
    old = conn.execute("SELECT * FROM project_registry WHERE project_code=?", (old_code,)).fetchone()
    if old:
        cols = [r["name"] for r in conn.execute("PRAGMA table_info(project_registry)")]
        vals = {c: old[c] for c in cols if c in old.keys()}
        vals["project_code"] = new_code
        if "created_at" in vals:
            vals["created_at"] = started
        if "updated_at" in vals:
            vals["updated_at"] = started
        if "updated_by" in vals:
            vals["updated_by"] = "system-split-migration"
        col_sql = ", ".join(vals.keys())
        q_sql = ", ".join("?" for _ in vals)
        conn.execute(f"INSERT OR IGNORE INTO project_registry({col_sql}) VALUES ({q_sql})", tuple(vals.values()))
    if conn.execute("SELECT 1 FROM project_tasks WHERE project_code=? LIMIT 1", (old_code,)).fetchone():
        conn.execute(
            """
            INSERT OR IGNORE INTO project_tasks(project_code, task_id, status, include_flag, comment, revision, created_at, updated_at, updated_by)
            SELECT ?, task_id, status, include_flag, comment, revision, created_at, ?, 'system-split-migration'
            FROM project_tasks WHERE project_code=?
            """,
            (new_code, started, old_code),
        )


def import_sources(conn: sqlite3.Connection, cfg: dict) -> dict:
    started = now_iso()
    seed_static_tables(conn, cfg)
    result = {"imported_at": started, "financial_projects": 0, "financial_lines": 0, "labor_rows": 0, "new_projects": 0, "messages": []}
    stale_codes: list[str] = []
    financial_path = resolve_path(cfg.get("financials_path"))
    labor_path = resolve_path(cfg.get("labor_detail_path"))
    if not financial_path or not financial_path.exists():
        result["messages"].append(f"Financials file not found: {financial_path}")
    else:
        fh = file_hash(financial_path)
        projects, financial_lines = parse_financials(financial_path)
        result["financial_projects"] = len(projects)
        result["financial_lines"] = len(financial_lines)
        conn.execute("DELETE FROM financial_lines")
        for line in financial_lines:
            conn.execute(
                """
                INSERT INTO financial_lines(import_hash, project_code, base_project_code, phase_code, phase_name, vp_project, description, budget, effort_to_date, source_row, imported_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (fh, line["project_code"], line.get("base_project_code", project_base_code(line["project_code"])), line.get("phase_code", ""), line.get("phase_name", ""), line.get("vp_project", ""), line["description"], line["budget"], line["effort_to_date"], line["source_row"], started),
            )
        for p in projects:
            existing = conn.execute("SELECT project_code FROM projects WHERE project_code=?", (p["project_code"],)).fetchone()
            if not existing:
                result["new_projects"] += 1
            conn.execute(
                """
                INSERT INTO projects(project_code, project_name, parent_name, budget, effort_to_date, vp_projects_json, financial_source_rows_json, updated_from_financials_at, financial_import_hash, base_project_code, phase_code, phase_name, vp_project)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(project_code) DO UPDATE SET
                    project_name=excluded.project_name,
                    parent_name=excluded.parent_name,
                    budget=excluded.budget,
                    effort_to_date=excluded.effort_to_date,
                    vp_projects_json=excluded.vp_projects_json,
                    financial_source_rows_json=excluded.financial_source_rows_json,
                    updated_from_financials_at=excluded.updated_from_financials_at,
                    financial_import_hash=excluded.financial_import_hash,
                    base_project_code=excluded.base_project_code,
                    phase_code=excluded.phase_code,
                    phase_name=excluded.phase_name,
                    vp_project=excluded.vp_project
                """,
                (
                    p["project_code"],
                    p["project_name"] or p["project_code"],
                    p.get("parent_name", ""),
                    p["budget"],
                    p["effort_to_date"],
                    json.dumps(p.get("vp_projects", [])),
                    json.dumps(p.get("financial_source_rows", [])),
                    started,
                    fh,
                    p.get("base_project_code", project_base_code(p["project_code"])),
                    p.get("phase_code", ""),
                    p.get("phase_name", ""),
                    p.get("vp_project", ""),
                ),
            )
        # Remove old VantagePoint-sourced project rows that are no longer present in
        # the current financial export. Manual projects are retained. This prevents stale
        # non-numeric phases and prior duplicate project-total rows from remaining visible.
        current_codes = {p["project_code"] for p in projects}
        stale_codes = [r["project_code"] for r in conn.execute(
            "SELECT project_code FROM projects WHERE coalesce(project_type,'vantagepoint')<>'manual' AND coalesce(financial_import_hash,'')<>''"
        ) if r["project_code"] not in current_codes]
        # Do not delete stale rows yet. Some stale unsuffixed rows contain user
        # task/status edits that need to be copied to newly split sibling rows below.
        # They are deleted after the registry/task seeding loop.

        conn.execute(
            "INSERT INTO source_files(file_kind, path, file_hash, imported_at, row_count, status, message) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("financials", str(financial_path), fh, started, len(financial_lines), "ok", f"Removed {len(stale_codes)} stale VantagePoint project rows"),
        )

    labor_defaults: dict[str, dict] = {}
    if not labor_path or not labor_path.exists():
        result["messages"].append(f"Labor detail file not found: {labor_path}")
    else:
        lh = file_hash(labor_path)
        labor_rows, labor_defaults = parse_labor_detail(labor_path, conn_staff_rows(conn))
        result["labor_rows"] = len(labor_rows)
        conn.execute("DELETE FROM labor_lines")
        for line in labor_rows:
            conn.execute(
                """
                INSERT INTO labor_lines(import_hash, project_code, employee_id, employee_raw, employee, role, team, labor_date, hours, billing, source_row, imported_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (lh, line["project_code"], line["employee_id"], line["employee_raw"], line["employee"], line["role"], line["team"], line["labor_date"], line["hours"], line["billing"], line["source_row"], started),
            )
        conn.execute("DELETE FROM labor_defaults")
        for code, d in labor_defaults.items():
            conn.execute(
                """
                INSERT INTO labor_defaults(project_code, default_witness, default_project_manager, default_analyst, default_start_date, default_filing_date, default_hearing_date, computed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    code,
                    d.get("default_witness", ""),
                    d.get("default_project_manager", ""),
                    d.get("default_analyst", ""),
                    d.get("default_start_date", ""),
                    d.get("default_filing_date", ""),
                    d.get("default_hearing_date", ""),
                    started,
                ),
            )
        conn.execute(
            "INSERT INTO source_files(file_kind, path, file_hash, imported_at, row_count, status, message) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("labor_detail", str(labor_path), lh, started, len(labor_rows), "ok", ""),
        )

    # Seed registry and task rows. Do not overwrite user-entered values; fill blanks only.
    for p in conn.execute("SELECT project_code, budget, effort_to_date FROM projects"):
        code = p["project_code"]
        base_code = project_base_code(code)
        phase_code = p["phase_code"] if "phase_code" in p.keys() else ""
        phase_name = p["phase_name"] if "phase_name" in p.keys() else ""
        d = labor_defaults.get(code) or labor_defaults.get(base_code) or dict(conn.execute("SELECT * FROM labor_defaults WHERE project_code=?", (base_code,)).fetchone() or {})
        copy_legacy_registry_and_tasks_for_split(conn, code, started)
        existing = conn.execute("SELECT * FROM project_registry WHERE project_code=?", (code,)).fetchone()
        default_status = infer_status(p["budget"], p["effort_to_date"], phase_code, phase_name)
        if existing is None:
            conn.execute(
                """
                INSERT INTO project_registry(project_code, status, witness, project_manager, analyst, start_date, filing_date, hearing_date, notes, revision, created_at, updated_at, updated_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, '', 1, ?, ?, 'system')
                """,
                (
                    code,
                    default_status,
                    d.get("default_witness", ""),
                    d.get("default_project_manager", ""),
                    d.get("default_analyst", ""),
                    d.get("default_start_date", ""),
                    d.get("default_filing_date", ""),
                    d.get("default_hearing_date", ""),
                    started,
                    started,
                ),
            )
        else:
            # Fill blanks only. Never clobber manual entries.
            updates = {}
            if not existing["status"] or existing["status"] == "Unassigned":
                updates["status"] = default_status
            for field, default_key in [
                ("witness", "default_witness"),
                ("project_manager", "default_project_manager"),
                ("analyst", "default_analyst"),
                ("start_date", "default_start_date"),
                ("filing_date", "default_filing_date"),
                ("hearing_date", "default_hearing_date"),
            ]:
                if not existing[field] and d.get(default_key):
                    updates[field] = d[default_key]
            if updates:
                sets = ", ".join(f"{k}=?" for k in updates)
                conn.execute(f"UPDATE project_registry SET {sets}, updated_at=?, updated_by=? WHERE project_code=?", tuple(updates.values()) + (started, "system", code))

        seed_project_tasks(conn, code)

    for stale in stale_codes:
        conn.execute("DELETE FROM projects WHERE project_code=?", (stale,))
    return result


def get_state(conn: sqlite3.Connection) -> dict:
    role_assumptions, standard_hours, blended_rate = role_metrics_from_db(conn)
    staff = []
    rates_lookup = {r["billing_role"]: parse_num(r["rate"]) for r in conn.execute("SELECT billing_role, rate FROM billing_rates")}
    for r in conn.execute("SELECT * FROM staff ORDER BY employee"):
        rec = dict(r)
        rec["billing_role"] = rec.get("billing_role") or default_billing_role(rec.get("employee"), rec.get("role"))
        rec["billing_rate"] = rates_lookup.get(rec["billing_role"], 0.0)
        rec["hours_per_week"] = parse_num(rec.get("hours_per_week")) or 40.0
        rec["pto_days"] = DEFAULT_PTO_DAYS
        rec["holiday_days"] = DEFAULT_HOLIDAYS_DAYS
        rec["nonworking_days"] = DEFAULT_NONWORKING_DAYS
        if rec.get("target_utilization") is None:
            rec["target_utilization"] = next((x["target_utilization"] for x in role_assumptions if x["role"] == rec.get("role")), 0.8)
        rec["target_utilization"] = parse_num(rec.get("target_utilization"))
        rec["annual_revenue"] = rec["billing_rate"] * (rec["hours_per_week"] / 5.0) * max(0.0, 260.0 - DEFAULT_NONWORKING_DAYS) * rec["target_utilization"]
        staff.append(rec)
    billing_rates = [dict(r) for r in conn.execute("SELECT * FROM billing_rates ORDER BY rate DESC, billing_role")]
    effort_distribution = [dict(r) for r in conn.execute("SELECT * FROM effort_distribution ORDER BY seq")]
    task_templates = [dict(r) for r in conn.execute("SELECT * FROM task_templates ORDER BY task_id")]
    projects = []
    pre_budget_by_base = defaultdict(float)
    post_count_by_base = defaultdict(int)
    for meta in conn.execute("SELECT project_code, base_project_code, phase_code, phase_name, budget FROM projects"):
        base = meta["base_project_code"] or project_base_code(meta["project_code"])
        stg = financial_phase_stage(meta["phase_code"] or "", meta["phase_name"] or "")
        if stg == TASK_STAGE_PREFILING:
            pre_budget_by_base[base] += parse_num(meta["budget"])
        elif stg == TASK_STAGE_POSTFILING:
            post_count_by_base[base] += 1
    for r in conn.execute(
        """
        SELECT p.*, r.status, r.witness, r.project_manager, r.analyst, r.start_date, r.filing_date, r.hearing_date,
               r.hearing_not_required, r.is_post_filing, r.project_name_override, r.budget_mode, r.prefiling_budget_override, r.post_filing_budget_override,
               r.post_filing_hours_override, r.budget_override, r.effort_override, r.override_reason, r.notes,
               r.revision AS registry_revision, r.updated_at AS registry_updated_at, r.updated_by AS registry_updated_by,
               d.default_witness, d.default_project_manager, d.default_analyst, d.default_start_date, d.default_filing_date, d.default_hearing_date
        FROM projects p
        LEFT JOIN project_registry r ON r.project_code=p.project_code
        LEFT JOIN labor_defaults d ON d.project_code=CASE WHEN p.base_project_code IS NOT NULL AND p.base_project_code<>'' THEN p.base_project_code ELSE p.project_code END
        ORDER BY COALESCE(NULLIF(r.project_name_override,''), p.project_name), p.project_code
        """
    ):
        rec = dict(r)
        rec["budget_source"] = parse_num(rec.get("budget"))
        rec["effort_source"] = parse_num(rec.get("effort_to_date"))
        budget_override = rec.get("budget_override")
        effort_override = rec.get("effort_override")
        rec["budget_override_active"] = budget_override is not None and str(budget_override) != ""
        rec["effort_override_active"] = effort_override is not None and str(effort_override) != ""
        rec["financial_override_active"] = bool(rec["budget_override_active"] or rec["effort_override_active"])
        rec["budget"] = parse_num(budget_override) if rec["budget_override_active"] else rec["budget_source"]
        rec["effort_to_date"] = parse_num(effort_override) if rec["effort_override_active"] else rec["effort_source"]
        budgeted_hours = rec["budget"] / blended_rate if rec["budget"] else 0.0
        rec["base_project_code"] = rec.get("base_project_code") or project_base_code(rec.get("project_code"))
        rec["phase_code"] = rec.get("phase_code") or ""
        rec["phase_name"] = rec.get("phase_name") or ""
        inferred_stage = financial_phase_stage(rec["phase_code"], rec["phase_name"])
        post_override = rec.get("is_post_filing")
        if post_override is None or str(post_override) == "":
            rec["phase_stage"] = inferred_stage
        elif int(post_override or 0) == 1:
            rec["phase_stage"] = TASK_STAGE_POSTFILING
        else:
            rec["phase_stage"] = TASK_STAGE_PREFILING if inferred_stage != "Exclude" else "Exclude"
        if str(rec.get("status") or "").lower() == "exclude":
            rec["phase_stage"] = "Exclude"
        rec["is_post_filing"] = 1 if rec["phase_stage"] == TASK_STAGE_POSTFILING else 0
        rec["end_date"] = rec.get("filing_date") or ""
        if rec["phase_stage"] == TASK_STAGE_POSTFILING:
            pre_budget, post_budget = 0.0, rec["budget"]
            budget_note = "Post-filing phase: VantagePoint budget/effort shown separately; workload forecast uses post-filing rule if needed"
        elif rec["phase_stage"] == "Exclude":
            pre_budget, post_budget = 0.0, 0.0
            budget_note = "Excluded phase: ignored for planning and capacity"
        else:
            pre_budget, post_budget = rec["budget"], 0.0
            budget_note = "Pre-filing phase: remaining pre-filing effort is scheduled through Filing Date"
        rec["prefiling_budget"] = pre_budget
        rec["post_filing_budget"] = post_budget
        rec["budget_mechanics_note"] = budget_note
        rec["budgeted_team_hours"] = budgeted_hours
        rec["project_name_source"] = rec.get("project_name") or rec["project_code"]
        rec["project_name_effective"] = (rec.get("project_name_override") or "").strip() or rec["project_name_source"]
        rec["hearing_not_required"] = 1 if hearing_is_na(rec.get("hearing_date"), rec.get("hearing_not_required") or 0) else 0
        if rec["hearing_not_required"]:
            rec["hearing_date_display"] = "N/A"
        else:
            rec["hearing_date_display"] = rec.get("hearing_date") or ""
        rec["prefiling_budgeted_hours"] = pre_budget / blended_rate if pre_budget else 0.0
        rec["post_filing_budgeted_hours"] = post_budget / blended_rate if post_budget else 0.0
        if rec["phase_stage"] == TASK_STAGE_POSTFILING:
            if rec["budget"] > 0:
                rec["post_filing_forecast_hours"] = max(0.0, (rec["budget"] - rec["effort_to_date"]) / blended_rate) if blended_rate else 0.0
            else:
                parent_pre_hours = (pre_budget_by_base.get(rec["base_project_code"], 0.0) / blended_rate) if blended_rate else 0.0
                rec["post_filing_forecast_hours"] = post_filing_forecast_hours(parent_pre_hours, rec.get("filing_date"), 0, 0) / max(1, post_count_by_base.get(rec["base_project_code"], 1))
        else:
            rec["post_filing_forecast_hours"] = 0.0
        rec["post_filing_forecast_dollars"] = rec["post_filing_forecast_hours"] * blended_rate
        rec["financial_pct"] = min(1.0, max(0.0, rec["effort_to_date"] / rec["budget"])) if rec["budget"] else (1.0 if rec["effort_to_date"] else 0.0)
        rec["budget_remaining"] = rec["budget"] - rec["effort_to_date"]
        rec["total_hours_remaining"] = remaining_hours_from_budget(rec["budget"], rec["effort_to_date"], blended_rate)
        if rec["phase_stage"] == TASK_STAGE_POSTFILING:
            rec["prefiling_effort_to_date"] = 0.0
            rec["post_filing_effort_to_date"] = rec["effort_to_date"]
        else:
            rec["prefiling_effort_to_date"] = rec["effort_to_date"]
            rec["post_filing_effort_to_date"] = 0.0
        rec["prefiling_budget_remaining"] = pre_budget - rec["prefiling_effort_to_date"]
        rec["post_filing_budget_remaining"] = post_budget - rec["post_filing_effort_to_date"]
        rec["prefiling_hours_remaining"] = max(0.0, rec["prefiling_budget_remaining"] / blended_rate) if blended_rate else 0.0
        rec["post_filing_hours_remaining"] = max(0.0, rec["post_filing_budget_remaining"] / blended_rate) if blended_rate else 0.0
        rec["prefiling_financial_pct"] = min(1.0, max(0.0, rec["prefiling_effort_to_date"] / pre_budget)) if pre_budget else (1.0 if rec["prefiling_effort_to_date"] else 0.0)
        rec["post_filing_financial_pct"] = min(1.0, max(0.0, rec["post_filing_effort_to_date"] / post_budget)) if post_budget else (1.0 if rec["post_filing_effort_to_date"] else 0.0)
        task_rows = [dict(x) for x in conn.execute(
            """
            SELECT pt.project_code, pt.task_id, tt.phase, tt.task, COALESCE(pt.base_hours_override, tt.base_hours) AS base_hours, pt.base_hours_override, tt.stage, pt.status, pt.include_flag, pt.comment, pt.revision, pt.updated_at, pt.updated_by
            FROM project_tasks pt JOIN task_templates tt ON tt.task_id=pt.task_id
            WHERE pt.project_code=? ORDER BY tt.task_id
            """,
            (rec["project_code"],),
        )]
        def pct_for(stage_name: str):
            rows = [x for x in task_rows if (x.get("stage") or TASK_STAGE_PREFILING) == stage_name and x["include_flag"] and x["status"] != "Not Required"]
            base = sum(x["base_hours"] for x in rows)
            weighted = sum(x["base_hours"] * TASK_STATUS_WEIGHT.get(x["status"], 0) for x in rows)
            return (min(1.0, max(0.0, weighted / base)) if base else 0.0, base)
        rec["prefiling_task_pct"], rec["prefiling_task_base_hours"] = pct_for(TASK_STAGE_PREFILING)
        rec["post_filing_task_pct"], rec["post_filing_task_base_hours"] = pct_for(TASK_STAGE_POSTFILING)
        included_base = sum(x["base_hours"] for x in task_rows if x["include_flag"] and x["status"] != "Not Required")
        weighted = sum(x["base_hours"] * TASK_STATUS_WEIGHT.get(x["status"], 0) for x in task_rows if x["include_flag"] and x["status"] != "Not Required")
        rec["task_pct"] = min(1.0, max(0.0, weighted / included_base)) if included_base else 0.0
        rec["task_remaining_hours"] = rec["prefiling_budgeted_hours"] * (1.0 - rec["prefiling_task_pct"]) + rec["post_filing_forecast_hours"] * (1.0 - rec["post_filing_task_pct"])
        rec["phase10_task_count"] = sum(1 for x in task_rows if (x.get("stage") or "") == TASK_STAGE_POSTFILING)
        rec["phase10_open_count"] = sum(1 for x in task_rows if (x.get("stage") or "") == TASK_STAGE_POSTFILING and x["include_flag"] and x["status"] not in ("Complete", "Not Required"))
        projects.append(rec)
    planning_units = [dict(r) for r in conn.execute("SELECT * FROM planning_units ORDER BY parent_project_code, unit_name, unit_id")]
    for u in planning_units:
        u["assignments"] = [dict(a) for a in conn.execute("SELECT role, employee, allocation_pct FROM planning_unit_assignments WHERE unit_id=? ORDER BY CASE role WHEN 'Witness' THEN 1 WHEN 'Project Manager' THEN 2 WHEN 'Analyst' THEN 3 WHEN 'Admin' THEN 4 ELSE 5 END, employee", (u["unit_id"],))]
    source_files = [dict(r) for r in conn.execute("SELECT * FROM source_files ORDER BY imported_at DESC LIMIT 20")]
    recent_audit = [dict(x) for x in conn.execute(
        """
        SELECT a.*, COALESCE(NULLIF(r.project_name_override,''), p.project_name, a.project_code, a.entity_key) AS project_name
        FROM audit_log a
        LEFT JOIN projects p ON p.project_code=a.project_code
        LEFT JOIN project_registry r ON r.project_code=a.project_code
        ORDER BY a.updated_at DESC, a.id DESC
        LIMIT 150
        """
    )]
    return {
        "generated_at": now_iso(),
        "blended_rate": blended_rate,
        "standard_project_hours": standard_hours,
        "status_options": STATUS_OPTIONS,
        "budget_mode_options": BUDGET_MODE_OPTIONS,
        "task_status_options": TASK_STATUS_OPTIONS,
        "task_status_weight": TASK_STATUS_WEIGHT,
        "role_assumptions": role_assumptions,
        "staff": staff,
        "billing_rates": billing_rates,
        "effort_distribution": effort_distribution,
        "task_templates": task_templates,
        "projects": projects,
        "planning_units": planning_units,
        "source_files": source_files,
        "recent_audit": recent_audit,
    }


def get_project_detail(conn: sqlite3.Connection, code: str) -> dict:
    state = get_state(conn)
    project = next((p for p in state["projects"] if p["project_code"] == code), None)
    if project:
        base_code_for_detail = project.get("base_project_code") or project_base_code(project.get("project_code") or code)
        if not int(project.get("is_post_filing") or 0):
            sibling_post_forecast = sum(parse_num(x.get("post_filing_forecast_hours")) for x in state["projects"] if (x.get("base_project_code") or project_base_code(x.get("project_code") or "")) == base_code_for_detail and int(x.get("is_post_filing") or 0))
            project = dict(project)
            project["post_filing_forecast_hours"] = sibling_post_forecast
            project["post_filing_forecast_dollars"] = sibling_post_forecast * parse_num(state.get("blended_rate"))
    tasks = [dict(x) for x in conn.execute(
        """
        SELECT pt.project_code, pt.task_id, tt.phase, tt.task, COALESCE(pt.base_hours_override, tt.base_hours) AS base_hours, pt.base_hours_override, tt.stage, pt.status, pt.include_flag, pt.comment, pt.revision, pt.updated_at, pt.updated_by
        FROM project_tasks pt JOIN task_templates tt ON tt.task_id=pt.task_id
        WHERE pt.project_code=? ORDER BY tt.task_id
        """,
        (code,),
    )]
    base_code = None
    if project:
        base_code = project.get("base_project_code") or project_base_code(project.get("project_code") or code)
    base_code = base_code or project_base_code(code)
    labor_summary = [dict(x) for x in conn.execute(
        """
        SELECT employee, employee_raw, role, team, SUM(hours) AS hours, SUM(billing) AS billing, MIN(labor_date) AS first_date, MAX(labor_date) AS last_date
        FROM labor_lines WHERE project_code IN (?, ?)
        GROUP BY employee, employee_raw, role, team
        ORDER BY hours DESC
        """,
        (code, base_code),
    )]
    units = [dict(x) for x in conn.execute("SELECT * FROM planning_units WHERE parent_project_code=? ORDER BY unit_name, unit_id", (code,))]
    for u in units:
        u["assignments"] = [dict(a) for a in conn.execute("SELECT role, employee, allocation_pct FROM planning_unit_assignments WHERE unit_id=? ORDER BY role, employee", (u["unit_id"],))]
    audit = [dict(x) for x in conn.execute("SELECT * FROM audit_log WHERE project_code=? OR entity_key LIKE ? ORDER BY updated_at DESC, id DESC LIMIT 100", (code, f"planning_unit:%:{code}"))]
    return {"project": project, "tasks": tasks, "labor_summary": labor_summary, "planning_units": units, "audit": audit}


def write_audit(conn, entity_type, entity_key, project_code, field_name, old_value, new_value, user):
    conn.execute(
        """
        INSERT INTO audit_log(entity_type, entity_key, project_code, field_name, old_value, new_value, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (entity_type, entity_key, project_code, field_name, str(old_value or ""), str(new_value or ""), user or "unknown", now_iso()),
    )


def update_registry(conn: sqlite3.Connection, payload: dict) -> dict:
    code = normalize_project_code(payload.get("project_code"))
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    expected_revision = payload.get("revision")
    fields = payload.get("fields") or {}
    allowed = {"status", "witness", "project_manager", "analyst", "start_date", "filing_date", "hearing_date", "hearing_not_required", "is_post_filing", "project_name_override", "budget_mode", "prefiling_budget_override", "post_filing_budget_override", "post_filing_hours_override", "budget_override", "effort_override", "override_reason", "notes"}
    row = conn.execute("SELECT * FROM project_registry WHERE project_code=?", (code,)).fetchone()
    if row is None:
        raise KeyError(f"Project registry row not found: {code}")
    if expected_revision is not None and int(expected_revision) != int(row["revision"]):
        return {"ok": False, "conflict": True, "current": dict(row)}
    updates = {}
    for k, v in fields.items():
        if k in allowed:
            if k in {"prefiling_budget_override", "post_filing_budget_override", "post_filing_hours_override"}:
                updates[k] = parse_num(v)
            elif k in {"budget_override", "effort_override"}:
                updates[k] = None if v is None or str(v).strip() == "" else parse_num(v)
            elif k in {"hearing_not_required", "is_post_filing"}:
                updates[k] = 1 if str(v).lower() in {"1", "true", "yes", "on"} or v is True else 0
            else:
                updates[k] = "" if v is None else str(v)
    if not updates:
        return {"ok": True, "revision": row["revision"]}
    for k, v in updates.items():
        if str(row[k] or "") != str(v or ""):
            write_audit(conn, "project_registry", code, code, k, row[k], v, user)
    sets = ", ".join(f"{k}=?" for k in updates)
    conn.execute(f"UPDATE project_registry SET {sets}, revision=revision+1, updated_at=?, updated_by=? WHERE project_code=?", tuple(updates.values()) + (now_iso(), user, code))
    newrow = conn.execute("SELECT * FROM project_registry WHERE project_code=?", (code,)).fetchone()
    return {"ok": True, "revision": newrow["revision"]}


def update_task(conn: sqlite3.Connection, payload: dict) -> dict:
    code = normalize_project_code(payload.get("project_code"))
    task_id = int(payload.get("task_id"))
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    expected_revision = payload.get("revision")
    fields = payload.get("fields") or {}
    allowed = {"status", "include_flag", "comment", "base_hours_override"}
    row = conn.execute("SELECT * FROM project_tasks WHERE project_code=? AND task_id=?", (code, task_id)).fetchone()
    if row is None:
        raise KeyError(f"Task row not found: {code}/{task_id}")
    if expected_revision is not None and int(expected_revision) != int(row["revision"]):
        return {"ok": False, "conflict": True, "current": dict(row)}
    updates = {}
    for k, v in fields.items():
        if k in allowed:
            updates[k] = int(v) if k == "include_flag" else (None if k == "base_hours_override" and v in (None, "") else (parse_num(v) if k == "base_hours_override" else ("" if v is None else str(v))))
    if updates.get("status") == "Not Required":
        updates["include_flag"] = 0
    elif "status" in updates:
        updates["include_flag"] = 1
    if updates.get("include_flag") == 1 and row["status"] == "Not Required" and "status" not in updates:
        updates["status"] = "Not Started"
    if not updates:
        return {"ok": True, "revision": row["revision"]}
    for k, v in updates.items():
        if str(row[k] or "") != str(v or ""):
            write_audit(conn, "project_task", f"{code}:{task_id}", code, k, row[k], v, user)
    sets = ", ".join(f"{k}=?" for k in updates)
    conn.execute(f"UPDATE project_tasks SET {sets}, revision=revision+1, updated_at=?, updated_by=? WHERE project_code=? AND task_id=?", tuple(updates.values()) + (now_iso(), user, code, task_id))
    newrow = conn.execute("SELECT * FROM project_tasks WHERE project_code=? AND task_id=?", (code, task_id)).fetchone()
    return {"ok": True, "revision": newrow["revision"]}




def aggregate_status_from_rows(rows: list[sqlite3.Row]) -> str:
    statuses = [str(r["status"] or "Not Started") for r in rows]
    if not statuses:
        return "Not Started"
    if all(s == statuses[0] for s in statuses):
        return statuses[0]
    weights = [TASK_STATUS_WEIGHT.get(s, 0.0) for s in statuses]
    avg = sum(weights) / max(1, len(weights))
    if avg >= 0.98:
        return "Complete"
    if avg <= 0.02:
        return "Not Started"
    return "In Progress"


def update_phase(conn: sqlite3.Connection, payload: dict) -> dict:
    # Update a full project phase by applying the change to all underlying task rows.
    # The UI now tracks depreciation-study progress at the phase level. We keep the
    # existing project_tasks table underneath so historical task data and task-based
    # completion calculations continue to work.
    code = normalize_project_code(payload.get("project_code"))
    phase = str(payload.get("phase") or "").strip()
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    fields = payload.get("fields") or {}
    if not code or not phase:
        raise ValueError("Project code and phase are required")
    rows = [dict(r) for r in conn.execute(
        """
        SELECT pt.project_code, pt.task_id, pt.status, pt.include_flag, pt.comment, pt.revision,
               pt.base_hours_override, tt.phase, tt.task, tt.base_hours, tt.stage
        FROM project_tasks pt JOIN task_templates tt ON tt.task_id=pt.task_id
        WHERE pt.project_code=? AND tt.phase=?
        ORDER BY tt.task_id
        """,
        (code, phase),
    )]
    if not rows:
        raise KeyError(f"Phase not found: {code}/{phase}")

    now = now_iso()
    if "status" in fields:
        new_status = str(fields.get("status") or "Not Started")
        if new_status not in TASK_STATUS_OPTIONS:
            raise ValueError(f"Invalid phase status: {new_status}")
        old_status = aggregate_status_from_rows(rows)
        include_flag = 0 if new_status == "Not Required" else 1
        if old_status != new_status:
            write_audit(conn, "project_phase", f"{code}:{phase}", code, "status", old_status, new_status, user)
        conn.execute(
            """
            UPDATE project_tasks
            SET status=?, include_flag=?, revision=revision+1, updated_at=?, updated_by=?
            WHERE project_code=? AND task_id IN (
                SELECT task_id FROM task_templates WHERE phase=?
            )
            """,
            (new_status, include_flag, now, user, code, phase),
        )

    if "base_hours_override" in fields:
        raw_value = fields.get("base_hours_override")
        old_total = sum(parse_num(r.get("base_hours_override")) if r.get("base_hours_override") is not None else parse_num(r.get("base_hours")) for r in rows)
        default_total = sum(parse_num(r.get("base_hours")) for r in rows) or 1.0
        if raw_value is None or str(raw_value).strip() == "":
            new_total = default_total
            if abs(old_total - new_total) > 0.0001:
                write_audit(conn, "project_phase", f"{code}:{phase}", code, "base_hours_override", old_total, "default", user)
            conn.execute(
                """
                UPDATE project_tasks
                SET base_hours_override=NULL, revision=revision+1, updated_at=?, updated_by=?
                WHERE project_code=? AND task_id IN (
                    SELECT task_id FROM task_templates WHERE phase=?
                )
                """,
                (now, user, code, phase),
            )
        else:
            new_total = max(0.0, parse_num(raw_value))
            ratio = new_total / default_total if default_total else 0.0
            if abs(old_total - new_total) > 0.0001:
                write_audit(conn, "project_phase", f"{code}:{phase}", code, "base_hours_override", old_total, new_total, user)
            for r in rows:
                conn.execute(
                    """
                    UPDATE project_tasks
                    SET base_hours_override=?, revision=revision+1, updated_at=?, updated_by=?
                    WHERE project_code=? AND task_id=?
                    """,
                    (parse_num(r.get("base_hours")) * ratio, now, user, code, r["task_id"]),
                )

    return {"ok": True}



def update_staff_settings(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    rows = payload.get("rows") or []
    if not rows:
        raise ValueError("No staff rows supplied")
    for r in rows:
        employee = str(r.get("employee") or "").strip()
        if not employee:
            continue
        old = conn.execute("SELECT * FROM staff WHERE employee=?", (employee,)).fetchone()
        old_json = json.dumps(dict(old), sort_keys=True) if old else ""
        role = str(r.get("role") or (old["role"] if old else "Analyst")).strip() or "Analyst"
        team = str(r.get("team") or "").strip()
        billing_role = str(r.get("billing_role") or default_billing_role(employee, role)).strip()
        hours_per_week = max(0.0, parse_num(r.get("hours_per_week")) or 40.0)
        pto_days = DEFAULT_PTO_DAYS
        target_utilization = max(0.0, min(1.0, pct_from_payload(r.get("target_utilization"))))
        active = 1 if str(r.get("active", "1")).lower() not in ("0", "false", "no") else 0
        conn.execute(
            """
            INSERT INTO staff(employee, role, team, billing_role, hours_per_week, pto_days, target_utilization, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(employee) DO UPDATE SET
                role=excluded.role, team=excluded.team, billing_role=excluded.billing_role,
                hours_per_week=excluded.hours_per_week, pto_days=excluded.pto_days,
                target_utilization=excluded.target_utilization, active=excluded.active
            """,
            (employee, role, team, billing_role, hours_per_week, pto_days, target_utilization, active),
        )
        new = conn.execute("SELECT * FROM staff WHERE employee=?", (employee,)).fetchone()
        new_json = json.dumps(dict(new), sort_keys=True) if new else ""
        if old_json != new_json:
            write_audit(conn, "staff", employee, None, "staff_settings", old_json, new_json, user)
    return {"ok": True}


def update_billing_rates(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    rows = payload.get("rows") or []
    if not rows:
        raise ValueError("No billing rate rows supplied")
    t = now_iso()
    for r in rows:
        billing_role = str(r.get("billing_role") or "").strip()
        if not billing_role:
            continue
        old = conn.execute("SELECT * FROM billing_rates WHERE billing_role=?", (billing_role,)).fetchone()
        old_json = json.dumps(dict(old), sort_keys=True) if old else ""
        rate = max(0.0, parse_num(r.get("rate")))
        conn.execute(
            """
            INSERT INTO billing_rates(billing_role, rate, updated_at, updated_by) VALUES (?, ?, ?, ?)
            ON CONFLICT(billing_role) DO UPDATE SET rate=excluded.rate, updated_at=excluded.updated_at, updated_by=excluded.updated_by
            """,
            (billing_role, rate, t, user),
        )
        new = conn.execute("SELECT * FROM billing_rates WHERE billing_role=?", (billing_role,)).fetchone()
        new_json = json.dumps(dict(new), sort_keys=True) if new else ""
        if old_json != new_json:
            write_audit(conn, "billing_rates", billing_role, None, "billing_rate", old_json, new_json, user)
    return {"ok": True}


def pct_from_payload(value) -> float:
    v = parse_num(value)
    return v / 100.0 if v > 1.0 else v


def update_role_assumptions(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    rows = payload.get("rows") or []
    if not rows:
        raise ValueError("No role assumption rows supplied")
    valid_roles = {r["role"] for r in ROLE_ASSUMPTIONS}
    updates = []
    for r in rows:
        role = str(r.get("role") or "").strip()
        if role not in valid_roles:
            continue
        updates.append((role, max(0.0, parse_num(r.get("standard_hours"))), max(0.0, parse_num(r.get("rate"))), max(0.0, min(1.0, pct_from_payload(r.get("target_utilization"))))))
    if not updates:
        raise ValueError("No valid role assumption rows supplied")
    total = sum(x[1] for x in updates) or 1.0
    for role, standard_hours, rate, target_utilization in updates:
        old = conn.execute("SELECT * FROM role_assumptions WHERE role=?", (role,)).fetchone()
        old_json = json.dumps(dict(old), sort_keys=True) if old else ""
        hour_share = standard_hours / total if total else 0.0
        conn.execute(
            """
            INSERT INTO role_assumptions(role, standard_hours, rate, target_utilization, hour_share) VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(role) DO UPDATE SET standard_hours=excluded.standard_hours, rate=excluded.rate, target_utilization=excluded.target_utilization, hour_share=excluded.hour_share
            """,
            (role, standard_hours, rate, target_utilization, hour_share),
        )
        new = conn.execute("SELECT * FROM role_assumptions WHERE role=?", (role,)).fetchone()
        new_json = json.dumps(dict(new), sort_keys=True) if new else ""
        if old_json != new_json:
            write_audit(conn, "role_assumptions", role, None, "role_assumptions", old_json, new_json, user)
    return {"ok": True}


def update_effort_distribution(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    rows = payload.get("rows") or []
    if not rows:
        raise ValueError("No effort distribution rows supplied")
    for r in rows:
        seq = int(parse_num(r.get("seq")))
        if seq <= 0:
            continue
        old = conn.execute("SELECT * FROM effort_distribution WHERE seq=?", (seq,)).fetchone()
        old_json = json.dumps(dict(old), sort_keys=True) if old else ""
        values = (
            seq,
            max(0.0, pct_from_payload(r.get("timeline_pct"))),
            int(parse_num(r.get("day_number"))),
            max(0.0, pct_from_payload(r.get("witness_pct"))),
            max(0.0, pct_from_payload(r.get("project_manager_pct"))),
            max(0.0, pct_from_payload(r.get("analyst_pct"))),
            max(0.0, pct_from_payload(r.get("admin_pct"))),
            max(0.0, pct_from_payload(r.get("combined_pct"))),
            str(r.get("comments") or ""),
        )
        conn.execute(
            """
            INSERT INTO effort_distribution(seq, timeline_pct, day_number, witness_pct, project_manager_pct, analyst_pct, admin_pct, combined_pct, comments)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(seq) DO UPDATE SET
                timeline_pct=excluded.timeline_pct, day_number=excluded.day_number, witness_pct=excluded.witness_pct,
                project_manager_pct=excluded.project_manager_pct, analyst_pct=excluded.analyst_pct,
                admin_pct=excluded.admin_pct, combined_pct=excluded.combined_pct, comments=excluded.comments
            """,
            values,
        )
        new = conn.execute("SELECT * FROM effort_distribution WHERE seq=?", (seq,)).fetchone()
        new_json = json.dumps(dict(new), sort_keys=True) if new else ""
        if old_json != new_json:
            write_audit(conn, "effort_distribution", str(seq), None, "effort_distribution", old_json, new_json, user)
    return {"ok": True}


def create_manual_project(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    code = normalize_project_code(payload.get("project_code"))
    if not code:
        raise ValueError("Project code is required")
    name = str(payload.get("project_name") or code).strip() or code
    parent = str(payload.get("parent_name") or "").strip()
    budget = parse_num(payload.get("budget"))
    effort = parse_num(payload.get("effort_to_date"))
    status = str(payload.get("status") or infer_status(budget, effort)).strip() or "Upcoming"
    t = now_iso()
    exists = conn.execute("SELECT project_code FROM projects WHERE project_code=?", (code,)).fetchone()
    conn.execute(
        """
        INSERT INTO projects(project_code, project_name, parent_name, budget, effort_to_date, project_type, updated_from_financials_at)
        VALUES (?, ?, ?, ?, ?, 'manual', ?)
        ON CONFLICT(project_code) DO UPDATE SET
            project_name=CASE WHEN projects.financial_import_hash IS NULL OR projects.financial_import_hash='' THEN excluded.project_name ELSE projects.project_name END,
            parent_name=CASE WHEN projects.financial_import_hash IS NULL OR projects.financial_import_hash='' THEN excluded.parent_name ELSE projects.parent_name END,
            budget=CASE WHEN projects.financial_import_hash IS NULL OR projects.financial_import_hash='' THEN excluded.budget ELSE projects.budget END,
            effort_to_date=CASE WHEN projects.financial_import_hash IS NULL OR projects.financial_import_hash='' THEN excluded.effort_to_date ELSE projects.effort_to_date END,
            project_type=CASE WHEN projects.financial_import_hash IS NULL OR projects.financial_import_hash='' THEN 'manual' ELSE projects.project_type END
        """,
        (code, name, parent, budget, effort, t),
    )
    row = conn.execute("SELECT * FROM project_registry WHERE project_code=?", (code,)).fetchone()
    if row is None:
        conn.execute(
            """
            INSERT INTO project_registry(project_code, status, witness, project_manager, analyst, start_date, filing_date, hearing_date, hearing_not_required, project_name_override, budget_override, effort_override, override_reason, notes, revision, created_at, updated_at, updated_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
            """,
            (
                code,
                status,
                str(payload.get("witness") or ""),
                str(payload.get("project_manager") or ""),
                str(payload.get("analyst") or ""),
                str(payload.get("start_date") or ""),
                str(payload.get("filing_date") or ""),
                str(payload.get("hearing_date") or ""),
                1 if payload.get("hearing_not_required") else 0,
                str(payload.get("project_name_override") or ""),
                None,
                None,
                str(payload.get("override_reason") or ""),
                str(payload.get("notes") or ""),
                t,
                t,
                user,
            ),
        )
    else:
        updates = {"status": status, "updated_at": t, "updated_by": user}
        conn.execute("UPDATE project_registry SET status=?, updated_at=?, updated_by=? WHERE project_code=?", (status, t, user, code))
    if "is_post_filing" in payload:
        conn.execute("UPDATE project_registry SET is_post_filing=? WHERE project_code=?", (1 if str(payload.get("is_post_filing")).lower() in {"1", "true", "yes", "on"} or payload.get("is_post_filing") is True else 0, code))
    seed_project_tasks(conn, code)
    write_audit(conn, "project", code, code, "manual_project", "created" if not exists else "updated", name, user)
    return {"ok": True, "project_code": code}



def delete_manual_project(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    code = normalize_project_code(payload.get("project_code"))
    row = conn.execute("SELECT * FROM projects WHERE project_code=?", (code,)).fetchone()
    if row is None:
        raise KeyError(f"Project not found: {code}")
    if str(row["project_type"] or "vantagepoint") != "manual" or str(row["financial_import_hash"] or ""):
        raise PermissionError("Only manual projects that do not come from VantagePoint can be deleted.")
    write_audit(conn, "project", code, code, "manual_project", "deleted", row["project_name"], user)
    conn.execute("DELETE FROM project_tasks WHERE project_code=?", (code,))
    conn.execute("DELETE FROM project_registry WHERE project_code=?", (code,))
    conn.execute("DELETE FROM projects WHERE project_code=?", (code,))
    return {"ok": True, "project_code": code}

def update_financial_override(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    code = normalize_project_code(payload.get("project_code"))
    row = conn.execute("SELECT * FROM project_registry WHERE project_code=?", (code,)).fetchone()
    if row is None:
        raise KeyError(f"Project registry row not found: {code}")
    clear_field = str(payload.get("clear_field") or "").strip()
    clear = bool(payload.get("clear"))
    new_budget = row["budget_override"]
    new_effort = row["effort_override"]
    if clear or clear_field == "all":
        new_budget = None
        new_effort = None
    elif clear_field == "budget":
        new_budget = None
    elif clear_field == "effort":
        new_effort = None
    else:
        if "budget_override" in payload:
            new_budget = None if payload.get("budget_override") in (None, "") else parse_num(payload.get("budget_override"))
        if "effort_override" in payload:
            new_effort = None if payload.get("effort_override") in (None, "") else parse_num(payload.get("effort_override"))
    reason = str(payload.get("reason") or "Edited from Portfolio financial cell").strip()
    for field, old, new in [("budget_override", row["budget_override"], new_budget), ("effort_override", row["effort_override"], new_effort), ("override_reason", row["override_reason"], reason)]:
        if str(old or "") != str(new or ""):
            write_audit(conn, "financial_override", code, code, field, old, new, user)
    conn.execute(
        "UPDATE project_registry SET budget_override=?, effort_override=?, override_reason=?, revision=revision+1, updated_at=?, updated_by=? WHERE project_code=?",
        (new_budget, new_effort, reason, now_iso(), user, code),
    )
    return {"ok": True, "project_code": code}


def upsert_planning_unit(conn: sqlite3.Connection, payload: dict) -> dict:
    user = str(payload.get("user") or "unknown").strip() or "unknown"
    action = str(payload.get("action") or "save").lower()
    t = now_iso()
    if action == "delete":
        unit_id = int(payload.get("unit_id"))
        row = conn.execute("SELECT * FROM planning_units WHERE unit_id=?", (unit_id,)).fetchone()
        if not row:
            return {"ok": True}
        conn.execute("DELETE FROM planning_units WHERE unit_id=?", (unit_id,))
        write_audit(conn, "planning_unit", f"planning_unit:{unit_id}:{row['parent_project_code']}", row["parent_project_code"], "delete", row["unit_name"], "", user)
        return {"ok": True}
    parent = normalize_project_code(payload.get("parent_project_code"))
    if not parent:
        raise ValueError("Parent project code is required")
    if not conn.execute("SELECT project_code FROM projects WHERE project_code=?", (parent,)).fetchone():
        raise KeyError(f"Parent project not found: {parent}")
    unit_name = str(payload.get("unit_name") or "").strip()
    if not unit_name:
        raise ValueError("Planning unit name is required")
    allocation_pct = parse_num(payload.get("allocation_pct") or 0)
    status = str(payload.get("status") or "Active").strip() or "Active"
    start_date = str(payload.get("start_date") or "").strip()
    filing_date = str(payload.get("filing_date") or "").strip()
    hearing_date = str(payload.get("hearing_date") or "").strip()
    hearing_not_required = 1 if payload.get("hearing_not_required") in (True, 1, "1", "true", "yes", "on") else 0
    unit_id = payload.get("unit_id")
    if unit_id:
        unit_id = int(unit_id)
        row = conn.execute("SELECT * FROM planning_units WHERE unit_id=?", (unit_id,)).fetchone()
        if not row:
            raise KeyError(f"Planning unit not found: {unit_id}")
        conn.execute(
            """
            UPDATE planning_units SET unit_name=?, allocation_pct=?, status=?, start_date=?, filing_date=?, hearing_date=?, hearing_not_required=?, revision=revision+1, updated_at=?, updated_by=? WHERE unit_id=?
            """,
            (unit_name, allocation_pct, status, start_date, filing_date, hearing_date, hearing_not_required, t, user, unit_id),
        )
    else:
        cur = conn.execute(
            """
            INSERT INTO planning_units(parent_project_code, unit_name, allocation_pct, status, start_date, filing_date, hearing_date, hearing_not_required, revision, created_at, updated_at, updated_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
            """,
            (parent, unit_name, allocation_pct, status, start_date, filing_date, hearing_date, hearing_not_required, t, t, user),
        )
        unit_id = cur.lastrowid
    conn.execute("DELETE FROM planning_unit_assignments WHERE unit_id=?", (unit_id,))
    assignments = payload.get("assignments") or []
    for a in assignments:
        role = str(a.get("role") or "").strip()
        employee = str(a.get("employee") or "").strip()
        pct = parse_num(a.get("allocation_pct") or 100)
        if role and employee and pct > 0:
            conn.execute("INSERT OR REPLACE INTO planning_unit_assignments(unit_id, role, employee, allocation_pct) VALUES (?, ?, ?, ?)", (unit_id, role, employee, pct))
    write_audit(conn, "planning_unit", f"planning_unit:{unit_id}:{parent}", parent, "save", "", json.dumps({"unit_name": unit_name, "allocation_pct": allocation_pct}), user)
    return {"ok": True, "unit_id": unit_id}

def export_table_csv(conn: sqlite3.Connection, kind: str) -> str:
    if kind == "registry":
        rows = [dict(r) for r in conn.execute(
            """
            SELECT p.project_code, p.project_name, r.project_name_override, p.budget AS imported_budget, p.effort_to_date AS imported_effort_to_date, r.budget_override, r.effort_override, r.override_reason, r.status, r.witness, r.project_manager, r.analyst, r.start_date, r.filing_date, r.hearing_date, r.hearing_not_required, r.budget_mode, r.prefiling_budget_override, r.post_filing_budget_override, r.post_filing_hours_override, r.notes, r.revision, r.updated_at, r.updated_by
            FROM projects p JOIN project_registry r ON r.project_code=p.project_code ORDER BY COALESCE(NULLIF(r.project_name_override,''), p.project_name), p.project_code
            """
        )]
    elif kind == "tasks":
        rows = [dict(r) for r in conn.execute(
            """
            SELECT pt.project_code, pt.task_id, tt.phase, tt.task, COALESCE(pt.base_hours_override, tt.base_hours) AS base_hours, pt.base_hours_override, tt.stage, pt.status, pt.include_flag, pt.comment, pt.revision, pt.updated_at, pt.updated_by
            FROM project_tasks pt JOIN task_templates tt ON tt.task_id=pt.task_id ORDER BY pt.project_code, pt.task_id
            """
        )]
    elif kind == "labor":
        rows = [dict(r) for r in conn.execute("SELECT * FROM labor_lines ORDER BY project_code, labor_date, employee_raw")]
    elif kind == "planning_units":
        rows = [dict(r) for r in conn.execute("SELECT pu.*, group_concat(pua.role || ':' || pua.employee || ':' || pua.allocation_pct, '; ') AS assignments FROM planning_units pu LEFT JOIN planning_unit_assignments pua ON pua.unit_id=pu.unit_id GROUP BY pu.unit_id ORDER BY pu.parent_project_code, pu.unit_name")]
    else:
        raise KeyError("Unknown export kind")
    if not rows:
        return ""
    import io
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


class AppContext:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.db_path = resolve_path(cfg.get("database_path")) or (APP_DIR / "resource_planner.sqlite")
        self.lock = threading.Lock()

    def conn(self):
        return connect(self.db_path)


CTX: AppContext | None = None


class Handler(BaseHTTPRequestHandler):
    server_version = "VRResourcePlanner/0.5"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), fmt % args))

    def send_json(self, obj, status=200):
        data = json.dumps(obj, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_text(self, text, content_type="text/plain; charset=utf-8", status=200):
        data = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self):
        try:
            self.handle_get()
        except Exception as e:
            traceback.print_exc()
            self.send_json({"ok": False, "error": str(e)}, 500)

    def do_POST(self):
        try:
            self.handle_post()
        except Exception as e:
            traceback.print_exc()
            self.send_json({"ok": False, "error": str(e)}, 500)

    def handle_get(self):
        global CTX
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/" or path == "/index.html":
            return self.serve_file(APP_DIR / "web" / "index.html")
        if path.startswith("/static/"):
            rel = posixpath.normpath(path[len("/static/"):]).lstrip("/")
            return self.serve_file(APP_DIR / "web" / rel)
        if path == "/api/state":
            with CTX.conn() as conn:
                return self.send_json(get_state(conn))
        if path.startswith("/api/project/"):
            code = normalize_project_code(urllib.parse.unquote(path.split("/")[-1]))
            with CTX.conn() as conn:
                return self.send_json(get_project_detail(conn, code))
        if path.startswith("/api/export/"):
            kind = path.split("/")[-1]
            with CTX.conn() as conn:
                data = export_table_csv(conn, kind)
            self.send_response(200)
            self.send_header("Content-Type", "text/csv; charset=utf-8")
            self.send_header("Content-Disposition", f"attachment; filename=vr_{kind}_export.csv")
            self.send_header("Content-Length", str(len(data.encode("utf-8"))))
            self.end_headers()
            self.wfile.write(data.encode("utf-8"))
            return
        self.send_json({"ok": False, "error": "Not found"}, 404)

    def handle_post(self):
        global CTX
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/import":
            with CTX.lock:
                with CTX.conn() as conn:
                    result = import_sources(conn, CTX.cfg)
            return self.send_json({"ok": True, "result": result})
        payload = self.read_json()
        if path == "/api/registry":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_registry(conn, payload)
                if result.get("conflict"):
                    conn.rollback()
                    return self.send_json(result, 409)
                conn.commit()
            return self.send_json(result)
        if path == "/api/task":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_task(conn, payload)
                if result.get("conflict"):
                    conn.rollback()
                    return self.send_json(result, 409)
                conn.commit()
            return self.send_json(result)
        if path == "/api/phase":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_phase(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/manual-project":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = create_manual_project(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/delete-manual-project":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = delete_manual_project(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/financial-override":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_financial_override(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/planning-unit":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = upsert_planning_unit(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/staff-settings":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_staff_settings(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/billing-rates":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_billing_rates(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/role-assumptions":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_role_assumptions(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/effort-distribution":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                result = update_effort_distribution(conn, payload)
                conn.commit()
            return self.send_json(result)
        if path == "/api/reset-billing-rates":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                reset_billing_rates_table(conn)
                write_audit(conn, "billing_rates", "defaults", None, "reset", "", "defaults restored", payload.get("user") or "unknown")
                conn.commit()
            return self.send_json({"ok": True})
        if path == "/api/reset-role-assumptions":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                reset_role_assumptions_table(conn)
                write_audit(conn, "role_assumptions", "defaults", None, "reset", "", "defaults restored", payload.get("user") or "unknown")
                conn.commit()
            return self.send_json({"ok": True})
        if path == "/api/reset-effort-distribution":
            with CTX.conn() as conn:
                conn.execute("BEGIN IMMEDIATE")
                reset_effort_distribution_table(conn, CTX.cfg)
                write_audit(conn, "effort_distribution", "defaults", None, "reset", "", "defaults restored", payload.get("user") or "unknown")
                conn.commit()
            return self.send_json({"ok": True})
        self.send_json({"ok": False, "error": "Not found"}, 404)

    def serve_file(self, path: Path):
        if not path.exists() or not path.is_file():
            return self.send_json({"ok": False, "error": "Not found"}, 404)
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--import-on-start", action="store_true", help="Import configured XLSX/CSV source files before starting the server")
    parser.add_argument("--import-only", action="store_true", help="Initialize/import and exit")
    args = parser.parse_args()
    cfg = load_config()
    global CTX
    CTX = AppContext(cfg)
    CTX.db_path.parent.mkdir(parents=True, exist_ok=True)
    with CTX.conn() as conn:
        init_db(conn)
        seed_static_tables(conn, cfg)
        if args.import_on_start or args.import_only:
            res = import_sources(conn, cfg)
            print(json.dumps(res, indent=2))
    if args.import_only:
        print(f"SQLite database ready: {CTX.db_path}")
        return
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"V&R Resource Planner running: http://{args.host}:{args.port}")
    print(f"SQLite database: {CTX.db_path}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
