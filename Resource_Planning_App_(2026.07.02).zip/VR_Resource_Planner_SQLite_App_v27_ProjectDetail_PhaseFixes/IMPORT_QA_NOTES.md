# Import QA notes - VP project suffix fix

This package fixes an import-key issue found with A0000431.001 Aqua Pennsylvania, Inc.-2026ADR-WasteWtr.

Prior behavior:
- The importer used only the VantagePoint project root to the left of the period.
- A0000431.000 and A0000431.001 both became app base project code 000431.
- Their phase 100 rows both became 000431.100 and were aggregated into one row.

Current behavior:
- .000 projects keep the legacy six-digit/root code for compatibility.
- Non-.000 VantagePoint project suffixes are preserved with a hyphen in the app code.
- Example: A0000431.001 phase 100 becomes 000431-001.100.
- Numeric phases only are imported. Non-numeric phases such as ZZREV and BDM remain excluded.
- New imported projects default to Active or Upcoming. The importer no longer marks a project Inactive simply because effort exceeds budget.

QA check from uploaded export:
- A0000431.000 phase 100 imports as 000431.100, budget $0, effort $3,090.
- A0000431.001 phase 100 imports as 000431-001.100, budget $10,870, effort $12,830.
- Nonnumeric project phases in imported project rows: 0.
- Nonnumeric project phases in financial_lines: 0.
- SQLite integrity check: ok.
